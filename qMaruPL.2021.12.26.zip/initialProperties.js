// # Author
// Katsuaki Maruno
// 
// # Copyright
// Copyright ©2021 OTSUKA CORPORATION
// 
// # License
// The source code is licensed MIT. The website content is licensed CC BY 4.0,see LICENSE.

// JavaScript

define([], function(){
	return {
		version: 1.0,
		qHyperCubeDef: {
			qDimensions: [],
			qMeasures: [],
			qInitialDataFetch: [
				{
					qWidth: 100,
					qHeight: 100
				}
			]
		},

		cube2: {
			qHyperCubeDef: {
				qDimensions: [],
				qMeasures: [],
				qInitialDataFetch: [
					{
						qWidth: 100,
						qHeight: 100
					}
				]
			}
		},
/*		
		second : {
			qHyperCubeDef : {
				qDimensions : [
//					{
//						qDef : {
//							qFieldDefs : ["Dim1"]
//						}
//					}
				],
				qMeasures : [
//					{
//						 qDef:{
//					 		qDef : "=Sum(Expression1)"}
//						}
//					}
				],
				qInitialDataFetch : [{
					qWidth : 10,
					qHeight : 50
				}]
			}
		}
*/
	}
})