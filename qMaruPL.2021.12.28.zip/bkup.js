// JavaScript
// # Author
// Katsuaki Maruno
// 
// # Copyright
// Copyright ©2021 OTSUKA CORPORATION
// 
// # License
// The source code is licensed MIT. The website content is licensed CC BY 4.0,see LICENSE.

define( [ "qlik" , 'jquery', 'text!./maruTemplate.html' , 'text!./style.css', './maruProperties' , './initialProperties' ],
    function ( qlik , $, template , cssContent , props , initialProps ) {
        'use strict';
		$( "<style>" ).html( cssContent ).appendTo( "head" );// スタイルシートを読み込む

        return {
			initialProperties: initialProps,
			definition: props,
			
			snapshot: {canTakeSnapshot: true},
			
			template: template,
			// 参考：https://www.buildinsider.net/web/angularjstips/0007
			controller: ['$scope', '$compile', '$sce', '$element','$window', function( $scope ,$compile ,$sce ,$element ,$window ) {
			

				console.log('element', $element); // この一行入れると大変役立つ。Chrome→縦三点リーダ→その他のツール→デベロッパーツール→で、オブジェクトの中身を確認できます 
				console.log('layout', $scope.layout); // この一行入れると大変役立つ。Chrome→縦三点リーダ→その他のツール→デベロッパーツール→で、オブジェクトの中身を確認できます 
				console.log('scope', $scope); // この一行入れると大変役立つ。Chrome→縦三点リーダ→その他のツール→デベロッパーツール→で、オブジェクトの中身を確認できます 

				// ========================================================================================
				// ========================================================================================
				// ========================================================================================
				// グローバル変数の初期化場所はここか？ここは1度しか呼ばれない。HTMLにバインドした場所だと何回もよばれてiteratorエラーがでる。
				$scope.sSUPERDEBUG = "";
				var G_bUseMeasProp = false;
				var G_aryMeasProps = [];
				

				var secondHyperCube;
				if( G_bUseMeasProp ){
//					addSecondCube( qlik.currApp(this) );// テスト中
				}

				// ========================================================================================
				// 関数の置き場所============================================================================
				// マウスボタンが押されると、この onclickMaru が呼ばれます
				$scope.onclickMaru = function( s1 ){
							alert(s1);
//							qlik.currApp().variable.setContent("vTest", $scope.moji1);
					// ヘルプはここ https://help.qlik.com/en-US/sense-developer/May2021/Subsystems/APIs/Content/Sense_ClientAPIs/CapabilityAPIs/NavigationAPI/gotoSheet-method.htm
					qlik.navigation.gotoSheet(s1);
				}

				// --------------------------------------------------------------------------------------------

				// 文字列のTrue、FalseをBooelanで返す。
				function myBoolCast( s999 ){
					var s1000;
					s1000 = String(s999).toLowerCase();
					if( s1000 == "true" )
						return true;
					else
						return false;
				}


				
				// 整数で返す。ダメなら２番目の引数を返す。最大最小を超えていたらそこで張り付く
				function myIntegerCast( s999 , nDefault, nMin=-65535, nMax=65535 ){
					var n1000;

					nDefault = String(nDefault);
					if( String(s999)=="NaN" ){
						s999 = nDefault;
					}

					var sPatternInteger1 = new RegExp(/^[+-]?\d+$/); // 正規表現で整数入力チェックする
					if( sPatternInteger1.test( s999 ) ){
						n1000 = parseInt( s999 );
					}
					else{
						n1000 = parseInt(nDefault);
					}
					
					if( n1000 < nMin ) n1000 = nMin;
						
					if( n1000 > nMax ) n1000 = nMax;
					
					return n1000;
				}

				// 文字列で返す。ダメなら２番目の引数を返す
				function myStringCast( s999 , sDefault="" ){
					var s1000;
					if( typeof s999 == "undefined" ){
						s1000 = sDefault;
					}
					else{
						s1000 = String( s999 );
					}
					return s1000;
				}

				// 色を表す文字列で返す。ダメなら２番目の引数を返す
				function myColorCast( s999 , sDefault ){
					var sPatternColor = new RegExp(/[0-9A-Za-z#]+/); // 正規表現でカラー表示チェックする
					var s1000;
					if( typeof s999 == "undefined" || ! sPatternColor.test( s1000 ) ){
						s1000 = sDefault;
					}
					else{
						s1000 = String( s999 );
					}
					return s1000;
				}

				// プロパティの値を構造体配列にする
				function setPropAry(){
					$scope.aryLv1=[];
					$scope.aryLv2=[];
					$scope.aryColspan=[];


					// --------------------------------------------------------------------------
					$scope.aryDim1 = [];	// ディメンションの中身の配列を作る
					if( $scope.layout.qHyperCube.qDimensionInfo.length==0 ){

					}				
					else{

						for( var iy1 = 0 ; iy1 < $scope.layout.qHyperCube.qSize.qcy ; iy1++ ){// ディメンション1のループ
//$scope.sDEBUG += "■iy1=" + iy1 + " / ";
//$scope.sDEBUG += "■qDataPages=" + $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText + " / ";
							var sDim = myStringCast( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText , "");
//$scope.sDEBUG += "■sDim=" + sDim + " / ";
							var bFind = false;
							for( var iDim1=0 ; iDim1<$scope.aryDim1.length ; iDim1++ ){
								if( $scope.aryDim1[iDim1] == sDim ){
									bFind = true;
									break;
								} 
							}
							if( ! bFind ){
								$scope.aryDim1.push( sDim );
							}
						}// <<< while( iy1 < $scope.
					}

//$scope.sDEBUG += "■ディメンションの長さ $scope.aryDim1.length=" + $scope.aryDim1.length + " / ";
//for( var iDim1=0 ; iDim1<$scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ確認/
//	$scope.sDEBUG += " $scope.aryDim1[" + iDim1 + "]=" + $scope.aryDim1[iDim1] + " / ";
//}					




					// --------------------------------------------------------------------------
					// 追加したハイパーキューブを安全のため読み出す。
				if( G_bUseMeasProp ){
				
//$scope.sDEBUG += " ■secondHyperCube=" + ( typeof secondHyperCube.qDataPages ) + " / ";

//$scope.sDEBUG += " ■メジャーの長さ=" + secondHyperCube.qDataPages[ 0 ].qMeasureInfo.length  + " / ";
					
					G_aryMeasProps = [];
					for( var iMeasureIndex1=0 
						; iMeasureIndex1 < secondHyperCube.qDataPages[ 0 ].qMeasureInfo.length 
						; iMeasureIndex1 ++	// メジャーがインクリメントされる 
					){// メジャー分ループ
						let oMeasProps;
						oMeasProps = new Object();
$scope.sDEBUG += " ■iMeasureIndex1=" + iMeasureIndex1  + " / ";

						oMeasProps.sMeasBGColor = 'white';
						oMeasProps.sMeasFontColor = 'black';
						oMeasProps.bBlink = false;
						if( typeof secondHyperCube == "undefined" ){
						}
						else if( typeof secondHyperCube.qDataPages[ 0 ].qMatrix[0][iMeasureIndex1].qAttrExps == "undefined" ){
						}
						else{
							if( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues.length>=3 ){
								oMeasProps.sMeasBGColor = myColorCast( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues[0].qText , 'white' );
							} 
							if( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues.length>=3 ){
								oMeasProps.sMeasFontColor = myColorCast( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues[1].qText , 'black' );
							} 
							if( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues.length>=3 ){
								oMeasProps.bBlink = myBoolCast( secondHyperCube.qDataPages[0].qMatrix[0][iMeasureIndex1].qAttrExps.qValues[2].qText , 'black' );
							} 
						}
					

//$scope.sDEBUG += " oMeasProps=" + oMeasProps.sMeasBGColor + " / ";


//$scope.sDEBUG += " ■qcy=" + $scope.layout.qHyperCube.qSize.qcy  + " / ";
						// ディメンション分ループ
						var aryDimProps = [];
						for( var iy1=0 ; iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.aryDim1.length > 0 ; iy1++ ){
//$scope.sDEBUG += " ■iy1=" + iy1  + " / ";
							let oDimProps;
							oDimProps = new Object();
							oDimProps.sMeasBGColor = 'white';
							oDimProps.sMeasFontColor = 'black';
							oDimProps.bBlink = false;
							
							// qAttrExps オブジェクトが存在するかtypeofでチェック。メジャーのプロパティなので、デフォルトで生成されなければ、存在しないメジャーもたくさんある。
							if( typeof $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps == "undefined" ){
							}else{
								// それぞれのメジャーのプロパティが存在するかチェック必要。配列なので長さをチェックする。
								if( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues.length>=3 ){
									oDimProps.sMeasBGColor = myColorCast( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues[0].qText , 'white' );
								}
								if( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues.length>=3 ){
									oDimProps.sMeasFontColor = myColorCast( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues[1].qText , 'black' );
								}
								if( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues.length>=3 ){
									oDimProps.bBlink = myBoolCast( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][iMeasureIndex1+1].qAttrExps.qValues[2].qText , 'black' );
								}
							}
							aryDimProps.push( oDimProps );
//$scope.sDEBUG += " oDimProps=" + oDimProps.sMeasBGColor + " / ";
						} // <<< for( var iy1=0 ; iy1 <
						
						oMeasProps.aryDimProps = aryDimProps;
						G_aryMeasProps.push( oMeasProps )	;
						
					} // <<< for( var iMeasureIndex1=0 
					
				} // <<< if( G_bUseMeasProp )
				else{
					G_aryMeasProps = [];
					for( var iMeasureIndex1=0 
						; iMeasureIndex1 < $scope.layout.qHyperCube.qDataPages[ 0 ].qMeasureInfo.length 
						; iMeasureIndex1 ++	// メジャーがインクリメントされる 
					){// メジャー分ループ
						let oMeasProps;
						oMeasProps = new Object();
						oMeasProps.sMeasBGColor = 'white';
						oMeasProps.sMeasFontColor = 'black';
						oMeasProps.bBlink = false;
				
						// ディメンション分ループ
						var aryDimProps = [];
						for( var iy1=0 ; iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.aryDim1.length > 0 ; iy1++ ){
							let oDimProps;
							oDimProps = new Object();
							oDimProps.sMeasBGColor = 'white';
							oDimProps.sMeasFontColor = 'black';
							oDimProps.bBlink = false;
						} // <<< for( var iy1=0 ; iy1 <
						
						aryDimProps.push( oDimProps );
						
						oMeasProps.aryDimProps = aryDimProps;
						G_aryMeasProps.push( oMeasProps )	;
						
					} // <<< for( var iMeasureIndex1=0 
				} // <<< else	
try{

}catch(e){
$scope.sDEBUG += " oMeasProps=例外発生 / ";
}


					// --------------------------------------------------------------------------
					var sPattern1 = new RegExp(/^[-]?([1-9]\d*|0)(\.\d+)?$/); // 正規表現で数値入力チェックする
					var sPattern2 = new RegExp(/[0-9A-Za-z#]+/); // 正規表現でカラー表示チェックする
					// --------------------------------------------------------------------------
					let oLv1;
					// --------------------------------------------------------------------------


					// Lv1 グループ====================================================
					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan1 , 99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName1 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align1 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign1 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC1 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC1 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary1 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut1 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink1 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );

					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan2 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName2 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align2 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC2 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC2 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary2 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut2 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink2 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan3 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName3 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align3 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign3 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC3 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC3 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary3 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut3 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink3 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan4 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName4 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align4 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign4 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC4 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC4 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary4 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut4 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink4 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan5 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName5 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align5 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC5 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC5 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary5 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut5 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink5 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan6 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName6 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align6 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign6 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC6 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC6 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary6 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut6 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink6 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan7 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName7 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align7 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign7 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC7 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC7 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary7 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut7 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink7 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan8 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName8 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align8 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign8 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC8 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC8 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary8 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut8 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink8 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan9 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName9 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align9 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign9 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC9 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC9 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary9 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut9 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink9 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan10 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName10 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align10 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign10 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC10 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC10 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary10 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut10 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink10 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan11 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName11 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align11 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign11 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC11 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC11 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary11 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut11 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink11 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan12 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName12 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align12 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign12 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC12 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC12 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary12 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut12 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink12 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan13 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName13 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align13 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign13 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC13 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC13 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary13 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut13 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink13 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan14 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName14 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align14 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign14 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC14 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC14 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary14 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut14 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink14 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan15 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName15 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align15 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign15 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC15 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC15 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary15 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut15 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink15 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan16 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName16 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align16 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign16 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC16 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC16 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary16 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut16 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink16 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv1Rowspan17 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName17 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align17 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign17 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC17 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC17 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary17 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut17 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink17 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );

					
					// fin
					oLv1 = new Object();
					oLv1.Rowspan = 100;
					oLv1.RowName = "　";
					oLv1.Align = "center";
					oLv1.VertiAlign = "middle";
					oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = "#111111" ;
					oLv1.Summary = false;
					oLv1.StandOut = false;
					oLv1.Blink = "false";
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					var nRageSum1 = 0;
//$scope.sDEBUG += " $scope.aryLv1.length=" + $scope.aryLv1.length +" /";
//$scope.sDEBUG += " Boolean=" + myBoolCast(true) +" /";
					for( var i1=0 ; i1 < $scope.aryLv1.length ; i1++ ){
						nRageSum1 += $scope.aryLv1[i1].Rowspan;
						$scope.aryLv1[i1].RangesumRS = nRageSum1;
//$scope.sDEBUG += " $scope.aryLv1["+i1+"].Rowspan=" + $scope.aryLv1[i1].Rowspan 
//	$scope.sDEBUG += " $scope.aryLv1["+i1+"].RowName=" + $scope.aryLv1[i1].RowName 
//	$scope.sDEBUG += " $scope.aryLv1["+i1+"].RangesumRS=" + $scope.aryLv1[i1].RangesumRS + " /";
					}



					// Lv2 グループ====================================================
					
					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv2Rowspan1 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName1 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align1 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign1 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC1 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC1 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary1 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut1 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv2Rowspan2 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName2 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align2 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC2 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC2 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary2 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut2 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv2Rowspan3 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName3 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align3 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign3 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC3 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC3 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary3 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut3 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv2Rowspan4 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName4 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align4 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign4 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC4 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC4 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary4 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut4 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = myIntegerCast( $scope.layout.settings.sLv2Rowspan5 ,99 , 1 , 999);
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName5 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align5 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign5 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC5 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC5 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary5 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut5 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					// lv2 fin
					oLv1 = new Object();
					oLv1.Rowspan = 1000;
					oLv1.RowName = "　";
					oLv1.Align = "center";
					oLv1.VertiAlign = "middle";
					oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( false );
					oLv1.StandOut = myBoolCast( false );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );


					nRageSum1 = 0;
//$scope.sDEBUG += " $scope.aryLv2.length=" + $scope.aryLv2.length +" /";
//$scope.sDEBUG += " Boolean=" + myBoolCast(false) +" /";
					for( var i1=0 ; i1 < $scope.aryLv2.length ; i1++ ){
						nRageSum1 += $scope.aryLv2[i1].Rowspan;
						$scope.aryLv2[i1].RangesumRS = nRageSum1;
//$scope.sDEBUG += " $scope.aryLv2["+i1+"].Rowspan=" + $scope.aryLv2[i1].Rowspan 
//	$scope.sDEBUG += " $scope.aryLv2["+i1+"].RowName=" + $scope.aryLv2[i1].RowName 
//	$scope.sDEBUG += " $scope.aryLv2["+i1+"].RangesumRS=" + $scope.aryLv2[i1].RangesumRS + " /";
					}





					// Colspan グループ====================================================
					
					//
					oLv1 = new Object();
					oLv1.nColspan = myIntegerCast( $scope.layout.settings.nColspan1 , 1 , 1 , 5);
					oLv1.sColspanText = myStringCast( $scope.layout.settings.sColspanText1 , "Measure Group1" );
					oLv1.sAlign = myStringCast( $scope.layout.settings.sColspanAlign1 , "center" );
					oLv1.sColspanBGC = myStringCast( $scope.layout.settings.sColspanBGC1 , "midnightblue" );
					$scope.aryColspan.push( oLv1 );

					oLv1 = new Object();
					oLv1.nColspan = myIntegerCast( $scope.layout.settings.nColspan2 , 1 , 1 , 4);
					oLv1.sColspanText = myStringCast( $scope.layout.settings.sColspanText2 , "Measure Group2" );
					oLv1.sAlign = myStringCast( $scope.layout.settings.sColspanAlign2 , "center" );
					oLv1.sColspanBGC = myStringCast( $scope.layout.settings.sColspanBGC2 , "midnightblue" );
					$scope.aryColspan.push( oLv1 );

					oLv1 = new Object();
					oLv1.nColspan = myIntegerCast( $scope.layout.settings.nColspan3 , 1 , 1 , 3);
					oLv1.sColspanText = myStringCast( $scope.layout.settings.sColspanText3 , "Measure Group3" );
					oLv1.sAlign = myStringCast( $scope.layout.settings.sColspanAlign3 , "center" );
					oLv1.sColspanBGC = myStringCast( $scope.layout.settings.sColspanBGC3 , "midnightblue" );
					$scope.aryColspan.push( oLv1 );

					oLv1 = new Object();
					oLv1.nColspan = myIntegerCast( $scope.layout.settings.nColspan4 , 1 , 1 , 2);
					oLv1.sColspanText = myStringCast( $scope.layout.settings.sColspanText4 , "Measure Group4" );
					oLv1.sAlign = myStringCast( $scope.layout.settings.sColspanAlign4 , "center" );
					oLv1.sColspanBGC = myStringCast( $scope.layout.settings.sColspanBGC4 , "midnightblue" );
					$scope.aryColspan.push( oLv1 );

					oLv1 = new Object();
					oLv1.nColspan = myIntegerCast( $scope.layout.settings.nColspan5 , 1 , 1 , 1);
					oLv1.sColspanText = myStringCast( $scope.layout.settings.sColspanText5 , "Measure Group5" );
					oLv1.sAlign = myStringCast( $scope.layout.settings.sColspanAlign5 , "center" );
					oLv1.sColspanBGC = myStringCast( $scope.layout.settings.sColspanBGC5 , "midnightblue" );
					$scope.aryColspan.push( oLv1 );

					oLv1 = new Object();
					oLv1.nColspan = 1;
					oLv1.sColspanText = "dummy";
					oLv1.sAlign = "center";
					oLv1.sColspanBGC = "darkgray";
					$scope.aryColspan.push( oLv1 );

					// colspanの累計値を取得しておく
					nRageSum1 = 0;
//$scope.sDEBUG += " $scope.aryColspan.length=" + $scope.aryColspan.length +" /";
					for( var i1=0 ; i1 < $scope.aryColspan.length ; i1++ ){
						nRageSum1 += $scope.aryColspan[i1].nColspan;
//$scope.sDEBUG += " nRageSum1=" + nRageSum1 + "/ "; 
						$scope.aryColspan[i1].RangesumCS = nRageSum1;
//$scope.sDEBUG += " $scope.aryColspan["+i1+"].RangesumCS=" + $scope.aryColspan[i1].RangesumCS + "/ "; 
//$scope.sDEBUG += " $scope.aryColspan["+i1+"].sColspanBGC=" + $scope.aryColspan[i1].sColspanBGC + "/ "; 
//$scope.sDEBUG += " $scope.aryColspan["+i1+"].sColspanText=" + $scope.aryColspan[i1].sColspanText + "/ "; 
//$scope.sDEBUG += " $scope.aryColspan["+i1+"].sAlign=" + $scope.aryColspan[i1].sAlign + "/ "; 
					}
					
					
					
					
					// どうもプロパティのデータ型を信用できない・・・
					$scope.prop_nMeasureCols = 1;
					if( $scope.layout.settings.bRepeatName == true){
						$scope.prop_nMeasureCols = 2;
					}

					$scope.prop_nRowBreak1 = myIntegerCast( $scope.layout.settings.nRowBreak1 , 1 , 1 , 5 );

					$scope.prop_nHeaderWidth0 = myIntegerCast( $scope.layout.settings.sHeaderWidth0 ,120,0);
					$scope.prop_nHeaderWidth1 = myIntegerCast( $scope.layout.settings.sHeaderWidth1 ,120,0);
					$scope.prop_nHeaderWidth2 = myIntegerCast( $scope.layout.settings.sHeaderWidth2 ,120,0);
					$scope.prop_nHeaderWidth3 = myIntegerCast( $scope.layout.settings.sHeaderWidth3 ,120,0);

					$scope.prop_nDimHeaderWidth1 = myIntegerCast( $scope.layout.settings.sDimHeaderWidth1 ,99, 0);

					$scope.prop_sMeasureNameAlign1 = myStringCast( $scope.layout.settings.sMeasureNameAlign1 , "left" );
//$scope.sDEBUG += " $scope.prop_sMeasureNameAlign1=" + $scope.layout.settings.sMeasureNameAlign1; 


					$scope.prop_styleWritingMode1;// 縦書きか否か
					if( myBoolCast( $scope.layout.settings.bLv2WritingMode ) ){
						$scope.prop_styleWritingMode1 = "writing-mode: vertical-rl; display: inline-block; ";
					}else{$scope.prop_styleWritingMode1="";}


					$scope.prop_TopTotalHeaderText = $scope.layout.settings.sHeaderTextTopTotal;
					$scope.prop_aryTotalHeaderText = [];
					$scope.prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderText3 );
					$scope.prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal2 );
					$scope.prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal3 );
					$scope.prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal4 );
					$scope.prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal5 );


					$scope.prop_bUseColspan;
					$scope.prop_bUseColspan = myBoolCast( $scope.layout.settings.bUseColspan );
//$scope.sDEBUG += " $scope.prop_bUseColspan=" + $scope.prop_bUseColspan; 


					$scope.sWidthPxThickest = "4"; // 全体設定として、最も太い線の幅
					$scope.sHeaderLineColor = "darkgray"; // 全体設定として、ヘッダーの罫線の色

					$scope.nMeasureLabelFontSize = myIntegerCast( $scope.layout.settings.nFontSize2 , 10, 1, 100);
//$scope.sDEBUG += " $scope.nMeasureLabelFontSize=" + $scope.nMeasureLabelFontSize; 

					$scope.prop_sTableMode = "horizontal";//"vertical"

					return "";
				}// <<<$scope.setPropAry = function()
				
				



	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	function makeTopHeader(){
		var sHTML ="";

		// Lv2
		if( $scope.prop_nHeaderWidth0 > 0 ){
			sHTML += "<td style=' ' > </td>";
		}
		// Lv1
		if( $scope.prop_nHeaderWidth1 > 0 ){
			sHTML += "<td style='text-align:center;  '> </td>";
		}
		// ヘッダ列ループ $scope.prop_nRowBreak1
		if( $scope.prop_nHeaderWidth2 > 0 ){
			// メジャーのセット
			sHTML += "<td colspan=" + (2 * $scope.prop_nRowBreak1) + " bgcolor=" + $scope.layout.settings.sHeaderBGC1 
				+ " style='text-align:center; border-left: 1px solid "+$scope.sHeaderLineColor+"; border-top: 1px solid "+$scope.sHeaderLineColor+"; border-bottom: 1px solid "+$scope.sHeaderLineColor+"; ' ><p style='font-weight:bold; color:"
				+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>"+$scope.prop_TopTotalHeaderText+"</p></td>"; 
		}
		else{
			// メジャーのセット
			sHTML += "<td colspan=" + (1 * $scope.prop_nRowBreak1) + " bgcolor=" + $scope.layout.settings.sHeaderBGC1 
				+ " style='text-align:center; border-left: 1px solid "+$scope.sHeaderLineColor+"; border-top: 1px solid "+$scope.sHeaderLineColor+"; border-bottom: 1px solid "+$scope.sHeaderLineColor+"; ' ><p style='font-weight:bold; color:"
				+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>"+$scope.prop_TopTotalHeaderText+"</p></td>"; 
		}
		// 真ん中お尻						
		sHTML += "<td style='width: 5px; border-left:1px solid black;'><p> </p></td>";

		return sHTML;
	}


	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	function makeDimHeader( iDim1 ){
		var sHTML ="";
//$scope.sDEBUG += " makeDimHeader(" + iDim1 + ") / ";
		
		// ディメンションヘッダ
		// ディメンションのヘッダが続くsDimHeaderWidth1
		var sColSpan22 = "";
		if( $scope.prop_nRowBreak1 > 1  ){ // 改行する場合、
			if( $scope.prop_nHeaderWidth2 > 0 ){ // かつ、項目び幅が０じゃない場合、のみColSpan変更
				sColSpan22 = " colspan=" + ($scope.prop_nRowBreak1 * $scope.prop_nMeasureCols ) + " ";
			}
			else{
				sColSpan22 = " colspan=" + ($scope.prop_nRowBreak1  ) + " ";
			}// <<< 改行する場合、
		}
		else{
			if( $scope.prop_nHeaderWidth2 > 0 ){ // かつ、項目び幅が０じゃない場合、のみColSpan変更
				sColSpan22 = " colspan=" + ($scope.prop_nMeasureCols ) + " ";
			}
			else{
				sColSpan22 = " colspan=" + ($scope.prop_nRowBreak1  ) + " ";
			}// <<< 改行する場合、
		}
//$scope.sDEBUG += " $scope.layout.qHyperCube.qSize.qcy=" + $scope.layout.qHyperCube.qSize.qcy + " / ";
		// 
		var iy1;
		iy1 = 0;
		while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.aryDim1.length > 0 ){// ディメンションが一つある場合
		
			var sVLineMeasName4,sVLineMeasValue4;// 縦罫線の種類
			if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
				sVLineMeasName4 = ""; // 縦罫線
				sVLineMeasValue4 ="";
			}
			//
			{// dimension
				sVLineMeasName4 = " border-left: 3px double " + $scope.sHeaderLineColor 
					+ "; border-right: 1px solid " +$scope.sHeaderLineColor 
					+ "; border-top: 1px solid " +$scope.sHeaderLineColor 
					+ "; "; // 縦罫線
				sVLineMeasValue4 = " border-left: 3px double " +$scope.sHeaderLineColor+ "; "; // 縦罫線
			}
		
		
//$scope.sDEBUG += " ( $scope.aryDim1[" + iDim1 + "]=" + $scope.aryDim1[iDim1] + " / ";
//$scope.sDEBUG += " $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText = " + $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText + " ) / ";
			if( $scope.aryDim1[iDim1] == myStringCast( $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText , "" ) ){// 読み込むディメンションとスキップするディメンションの判断
//$scope.sDEBUG += " Hit / ";
				sHTML += "<td " + sColSpan22 + " bgcolor=" + $scope.layout.settings.sHeaderBGC2 
					+ " style='text-align:center; " + sVLineMeasName4 + "  '><p style='font-weight:bold; color:"
					+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>";
				sHTML += $scope.aryDim1[iDim1]; //  $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText;
				sHTML += "</p></td>";
			}
			iy1 = iy1 + 1;
		}
		// 右端お尻						
		sHTML += "<td style='width: 1px; border-left:1px solid black;'><p> </p></td>";
	
		return sHTML;
	}
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// 2行目ヘッダ　メジャーのヘッダ
	function makeMeasureHeader( sMode1 /*grand dimension */, iDim1 /*ディメンションインデックス*/){
		var sHTML ="";
	
		if( sMode1 == "grand" ){// グランドのみ表示
			// Lv2
			if( $scope.prop_nHeaderWidth0 > 0 ){
				sHTML += "<td  bgcolor=" + $scope.layout.settings.sHeaderBGC1 
					+ " style='text-align:center;  border:1px solid "+$scope.sHeaderLineColor+";'><p style='font-weight:bold; color:" 
					+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText0
					+ "</p></td>";
			}
			// Lv1
			if( $scope.prop_nHeaderWidth1 > 0 ){
				sHTML += "<td  bgcolor=" + $scope.layout.settings.sHeaderBGC1 
					+ " style='text-align:center; border:1px solid "+$scope.sHeaderLineColor+";'><p style='font-weight:bold; color:" 
					+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText1
					+ "</p></td>";
			}
		}

//$scope.sDEBUG += " nRowBreak1=" + $scope.prop_nRowBreak1 + " /";
					
		// ヘッダ列ループ nRowBreak1
		for( var iMCol1=0 ; iMCol1 < $scope.prop_nRowBreak1 ; iMCol1++ ){
		
		
			var sVLineMeasName4,sVLineMeasValue4;// 縦罫線の種類
			if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
				sVLineMeasName4 = ""; // 縦罫線
				sVLineMeasValue4 ="";
			}
			//
			if( sMode1 == "grand" ){
				if( $scope.prop_nHeaderWidth2 > 0 ){
					sVLineMeasName4 = " border-left: 3px double " + $scope.sHeaderLineColor + "; "; // 縦罫線
					sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
				}
				else{
					sVLineMeasValue4 = " border-left: 3px double " + $scope.sHeaderLineColor + "; "; // 縦罫線
				}
			}
			else{// dimension
				if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){
					sVLineMeasName4 = " border-left: 3px double " + $scope.sHeaderLineColor + "; "; // 縦罫線
					sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
				}
				else{
					if( iMCol1==0 ){
						sVLineMeasValue4 = " border-left: 3px double " + $scope.sHeaderLineColor + "; "; // 縦罫線
					}
					else{
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
					}
				}
			}
		
		
			// メジャー名
			if( ( $scope.prop_nHeaderWidth2 > 0 && sMode1 == "grand" ) || ( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ) ){
				sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC1 
					+ " style='text-align:center; " + sVLineMeasName4 + " border-top:1px solid "+$scope.sHeaderLineColor+"; border-bottom:1px solid "+$scope.sHeaderLineColor+";'>" 
					+ "<p style='font-weight:bold; color:" 
					+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText2
					+ "</p></td>";
			}

			// メジャー値
			var sMeasureValueHeaderBGC = $scope.layout.settings.sHeaderBGC2; // メジャー値のヘッダーは、Measure Groupの背景色を踏襲する
			var nCountColspanIdx = 0;// 現在のColspanのインデックスを調べる
			for( var i45 = 0 ; i45<=iMCol1 && i45<10/*永久ループ防止*/ ; i45++ ){
				if( i45 >= $scope.aryColspan[nCountColspanIdx].RangesumCS ){
					nCountColspanIdx ++ ;
				}
			}
			sMeasureValueHeaderBGC = $scope.aryColspan[nCountColspanIdx].sColspanBGC; 

			sHTML += "<td bgcolor=" + sMeasureValueHeaderBGC 
				+ " style='text-align:center; " + sVLineMeasValue4 + " border-top:1px solid "+$scope.sHeaderLineColor+"; border-bottom:1px solid "+$scope.sHeaderLineColor+"; '>"
				+ "<p style='font-weight:bold; color:" 
				+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.prop_aryTotalHeaderText[iMCol1] + "</p></td>";

		}	// <<< for( var iMCol1 
	
		if( sMode1 == "grand" ){// グランドのみ表示
			// 真ん中お尻						
			sHTML += "<td style='width: 5px; border-left:1px solid black;'><p> </p></td>";
		}
		else{// ディメンションのみ表示
			// 右端お尻						
			sHTML += "<td style='width: 1px; border-left:1px solid black;'><p> </p></td>";
		}

		return sHTML;
	}
	
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// メジャーグループのヘッダ
	function makeMeasureGroup( sMode1 /*grand dimension */, iDim1 /*ディメンションインデックス*/){
		var sHTML ="";

		if( sMode1 == "grand" ){// グランドのみ表示
			// Lv2
			if( $scope.prop_nHeaderWidth0 > 0 ){
				sHTML += "<td style=' ' > </td>";
			}
			// Lv1
			if( $scope.prop_nHeaderWidth1 > 0 ){
				sHTML += "<td style='text-align:center;  '> </td>";
			}
		}
		
		// M
		for( var iMCol1=0 , iRunsumColspan=0 ; iMCol1 < $scope.prop_nRowBreak1 && iRunsumColspan < $scope.prop_nRowBreak1 ; iMCol1++ ){
			var nColspanHead1 = $scope.aryColspan[iMCol1].nColspan;
			// Colspan メジャー名とメジャー値は一緒くた
			var nBairitsu = 1;



			var sVLineMeasName4,sVLineMeasValue4;// 縦罫線の種類
			if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
				sVLineMeasName4 = ""; // 縦罫線
				sVLineMeasValue4 ="";
			}
			//
			if( sMode1 == "grand" ){
				if( $scope.prop_nHeaderWidth2 > 0 ){
					sVLineMeasName4 = " border-left: 3px double " +$scope.sHeaderLineColor+ "; "; // 縦罫線
					sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
				}
				else{
					sVLineMeasValue4 = " border-left: 3px double " +$scope.sHeaderLineColor+ "; "; // 縦罫線
				}
			}
			else{// dimension
				if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){
					sVLineMeasName4 = " border-left: 3px double " +$scope.sHeaderLineColor+ "; "; // 縦罫線
					sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
				}
				else{
					if( iMCol1==0 ){
						sVLineMeasValue4 = " border-left: 3px double " +$scope.sHeaderLineColor+ "; "; // 縦罫線
					}
					else{
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " " + $scope.sHeaderLineColor + "; "; // 
					}
				}
			}


			if( sMode1 == "grand" ){// グランドの場合
				if( $scope.prop_nHeaderWidth2 > 0 ){
					nBairitsu = 2 ;
				}
				sHTML += "<td colspan=" + nColspanHead1 * nBairitsu + " bgcolor=" + $scope.aryColspan[iMCol1].sColspanBGC  
					+ " style='text-align: " +$scope.aryColspan[iMCol1].sAlign + "; " + sVLineMeasValue4 + " "+$scope.sHeaderLineColor+"; border-top:1px solid "+$scope.sHeaderLineColor+"; border-bottom:1px solid "+$scope.sHeaderLineColor+";'>" 
					+ "<p style='font-weight:bold; color:" 
					+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.aryColspan[iMCol1].sColspanText
					+ "</p></td>";
			}
			else{// ディメンションの場合
				if( $scope.prop_nHeaderWidth2 > 0 ){
					nBairitsu *= $scope.prop_nMeasureCols;
				}
				if( iMCol1 == 0 /*&& $scope.prop_nMeasureCols == 1*/ ){// ディメンションの切り替えでなおかつ、メジャー項目が隠されている場合は、メジャー値が 2重太線
					sHTML += "<td colspan=" + nColspanHead1 * nBairitsu + " bgcolor=" + $scope.aryColspan[iMCol1].sColspanBGC 
						+ " style='text-align:"+$scope.aryColspan[iMCol1].sAlign+"; " + sVLineMeasValue4 + " "+$scope.sHeaderLineColor+"; border-top:1px solid "+$scope.sHeaderLineColor+"; border-bottom:1px solid "+$scope.sHeaderLineColor+";'>" 
						+ "<p style='font-weight:bold; color:" 
						+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.aryColspan[iMCol1].sColspanText
						+ "</p></td>";
				}
				else{
					sHTML += "<td colspan=" + nColspanHead1 * nBairitsu + " bgcolor=" + $scope.aryColspan[iMCol1].sColspanBGC 
						+ " style='text-align:"+$scope.aryColspan[iMCol1].sAlign+"; " + sVLineMeasValue4 + " "+$scope.sHeaderLineColor+"; border-top:1px solid "+$scope.sHeaderLineColor+"; border-bottom:1px solid "+$scope.sHeaderLineColor+";'>" 
						+ "<p style='font-weight:bold; color:" 
						+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.aryColspan[iMCol1].sColspanText
						+ "</p></td>";
				}

			}

			iRunsumColspan += nColspanHead1;
		}// for( var iMCol1=0 , iRunsumColspan=

		if( sMode1 == "grand" ){// グランドのみ表示
			// 真ん中お尻						
			sHTML += "<td style='width: 5px; border-left:1px solid black;'><p> </p></td>";
		}
		else{// ディメンションのみ表示
			// 右端お尻						
			sHTML += "<td style='width: 1px; border-left:1px solid black;'><p> </p></td>";
		}
		

		return sHTML;
	}

	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	function makeMatrix( sMode1 /*grand dimension */, iDim1 /*ディメンションインデックス*/
		, iMeasureIndex1, iRowspanLv1, iRowspanLv2, iCurrentRow1 ,iRangesumRowspanLv1, iRangesumRowspanLv2 
	){
		var sHTML ="";



		var sBdBottom3="";
		if( $scope.layout.settings.sLineHorizon1 == "none" ){// 横罫線
			sBdBottom3 = ""; // 横罫線
		}
		else{
			sBdBottom3 = " border-bottom: 1px " + $scope.layout.settings.sLineHorizon1 + " black; "; // 横罫線
		}
		
		if( $scope.layout.qHyperCube.qMeasureInfo.length - iMeasureIndex1 < $scope.prop_nRowBreak1 + 1 ){// 最終行
			sBdBottom3 = " border-bottom: 1px solid black; "; // 横罫線
		}

		if( iCurrentRow1 == $scope.layout.qHyperCube.qMeasureInfo.length -1 || iCurrentRow1 == $scope.aryLv1[iRowspanLv1].RangesumRS-1 ){// アンダーラインが絶対に必要
			sBdBottom3 = " border-bottom:1px solid black; ";
		}
		if( sMode1 == "grand" ){// グランドのみ表示
			// 大区分
			if( iRangesumRowspanLv2 < $scope.aryLv2[iRowspanLv2].RangesumRS ){
				if( $scope.prop_nHeaderWidth0 > 0 ){
					sHTML += "<td rowspan=" + $scope.aryLv2[iRowspanLv2].Rowspan + " bgcolor=" + $scope.aryLv2[iRowspanLv2].BGC ;
					sHTML +=  " style='text-align:" + $scope.aryLv2[iRowspanLv2].Align + "; border-left:1px solid black; border-top:1px solid black; border-right:1px solid black; border-bottom:1px solid black;" ;
					sHTML +=  " vertical-align:"+ $scope.aryLv2[iRowspanLv2].VertiAlign ;
					sHTML +=  "; '><p style='" + $scope.prop_styleWritingMode1 + " padding:0px 0px 0px 0px; font-weight:bold; font-size:" ;
					sHTML +=  $scope.layout.settings.nFontSize1 + "px; color:"+ $scope.aryLv2[iRowspanLv2].FGC +"' >" ;
					sHTML +=  $scope.aryLv2[iRowspanLv2].RowName +"</p></td>" ;
				}
			}
			// 合計科目
			// 点滅条件
			var sBlink="";
			if( $scope.aryLv1[iRowspanLv1].Blink ){
				sBlink = " class='blink' ";
			}
			
			if( iRangesumRowspanLv1 < $scope.aryLv1[iRowspanLv1].RangesumRS ){
				if( $scope.prop_nHeaderWidth1 > 0 ){
					sHTML += "<td "+ sBlink +" rowspan=" + $scope.aryLv1[iRowspanLv1].Rowspan + " bgcolor=" + $scope.aryLv1[iRowspanLv1].BGC ;
					sHTML += " style='text-align:" + $scope.aryLv1[iRowspanLv1].Align + "; border-left:1px solid black; border-top:1px solid black; border-bottom:1px solid black; border-right:1px solid black; " ;
					sHTML +=  " vertical-align:"+ $scope.aryLv1[iRowspanLv1].VertiAlign ;
					sHTML +=  ";'><p style='font-weight:bold; font-size:" + $scope.layout.settings.nFontSize1 + "px; color:"+ $scope.aryLv1[iRowspanLv1].FGC +"' >" ;
					sHTML +=  $scope.aryLv1[iRowspanLv1].RowName +"</p></td>";
				}
			}
		} // <<< sMode1



		var sSummaryLineMeasNameAlign = $scope.prop_sMeasureNameAlign1; // メジャー値のAlign
		var sSummaryLineBorderMeasName,sSummaryLineBorderMeasValue,sMeasureNameFont1,sMeasureValueFont2;
		sSummaryLineBorderMeasName="";
		sMeasureNameFont1="font-weight:normal; color:black; ";
		sMeasureValueFont2="font-weight:normal; color:black; ";
		sSummaryLineBorderMeasValue=" text-align: right; ";

		// 最終行の場合は下に線
		if( iMeasureIndex1 + $scope.prop_nRowBreak1 >= $scope.layout.qHyperCube.qMeasureInfo.length ){
			sSummaryLineBorderMeasName = " border-bottom:1px solid black; ";
			sSummaryLineBorderMeasValue = " border-bottom:1px solid black; ";
		}

		if( $scope.aryLv1[iRowspanLv1].Summary ){// 横線
			sSummaryLineBorderMeasName = " border-top:1px solid black; border-bottom:1px solid black; ";
			sSummaryLineBorderMeasValue = " border-top:1px solid black; border-bottom:1px solid black; ";
		}

		if( $scope.aryLv1[iRowspanLv1].StandOut ){// 色帯＋太字
			sSummaryLineBorderMeasName += "background-color:" + $scope.aryLv1[iRowspanLv1].BGC + "; ";
//			sSummaryLineBorderMeasValue += "background-color:" + $scope.aryLv1[iRowspanLv1].BGC + "; ";
			sSummaryLineMeasNameAlign = $scope.aryLv1[iRowspanLv1].Align;
			sMeasureNameFont1 = "font-weight:bold; color:"+ $scope.aryLv1[iRowspanLv1].FGC +"; ";
			sMeasureValueFont2 = "font-weight:bold; color:"+ $scope.aryLv1[iRowspanLv1].FGC +"; ";
		}




		// 中身列ループ $scope.prop_nRowBreak1
		for( var iMCol1=0 ; iMCol1 < $scope.prop_nRowBreak1  ; iMCol1++ ){
			if( iMCol1 < $scope.prop_nRowBreak1 && iMeasureIndex1 + iMCol1 < $scope.layout.qHyperCube.qMeasureInfo.length ){

				var sVLineMeasName4,sVLineMeasValue4;// 縦罫線の種類
				if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
					sVLineMeasName4 = ""; // 縦罫線
					sVLineMeasValue4 ="";
				}
				//
				if( sMode1 == "grand" ){
					if( $scope.prop_nHeaderWidth2 > 0 ){
						sVLineMeasName4 = " border-left: 3px double black; "; // 縦罫線
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
					}
					else{
						sVLineMeasValue4 = " border-left: 3px double black; "; // 縦罫線
					}
				}
				else{// dimension
					if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){
						sVLineMeasName4 = " border-left: 3px double black; "; // 縦罫線
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
					}
					else{
						if( iMCol1==0 ){
							sVLineMeasValue4 = " border-left: 3px double black; "; // 縦罫線
						}
						else{
							sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
						}
					}
				}

				// メジャーのプロパティによってアラート（フォントの色や背景色を変化させる）
				var sMeasBGColor="";
				var sMeasFontColor="";
				var sMeasBlink = "";
//$scope.sDEBUG += " G_aryMeasProps.length " + G_aryMeasProps.length + " <hr> ";

				if( sMode1 == "grand" ){
//$scope.sDEBUG += " grandメジャーの背景色 " + G_aryMeasProps[ iMeasureIndex1+ iMCol1 ].sMeasBGColor + " / "
//$scope.sDEBUG += " grandメジャーのフォント色 " + G_aryMeasProps[ iMeasureIndex1 + iMCol1 ].sMeasFontColor + " / "

					
					// それぞれのメジャーのプロパティが存在するかチェック必要。配列なので長さをチェックする。
					sMeasBGColor = myColorCast( G_aryMeasProps[ iMeasureIndex1 + iMCol1 ].sMeasBGColor , 'white' );
//$scope.sDEBUG += "Bg:"+	sMeasBGColor;

					sMeasFontColor = myColorCast( G_aryMeasProps[ iMeasureIndex1 + iMCol1 ].sMeasFontColor , 'black' );
//$scope.sDEBUG += "Font:"+	sMeasFontColor;

					if( G_aryMeasProps[ iMeasureIndex1 + iMCol1 ].bBlink ){
						sMeasBlink = " class='blink' ";
					}

				}
				else{// ディメンション毎に評価する必要がある場合
					// それぞれのメジャーのプロパティが存在するかチェック必要。配列なので長さをチェックする。
					sMeasBGColor = myColorCast( G_aryMeasProps[ iMeasureIndex1+ iMCol1 ].aryDimProps[ iDim1 ].sMeasBGColor , 'white' );
					sMeasFontColor = myColorCast( G_aryMeasProps[ iMeasureIndex1+ iMCol1 ].aryDimProps[ iDim1 ].sMeasFontColor , 'black' );
					if( G_aryMeasProps[ iMeasureIndex1+ iMCol1 ].aryDimProps[ iDim1 ].bBlink ){
						sMeasBlink = " class='blink' ";
					}
				}
				
				
				
				var sMeasNameBGColor = "white";
				if( ! $scope.aryLv1[iRowspanLv1].StandOut ){// Stand Out Band　でなければ
					sMeasureValueFont2 = " font-weight:normal; color:"+ sMeasFontColor +"; ";
				}
				else{// // Stand Out Bandの場合
					if( sMeasBGColor.toLowerCase()=='white' ){// アラートが設定されていないと思われる
						sMeasBGColor = $scope.aryLv1[iRowspanLv1].BGC;
						sMeasureValueFont2 = "font-weight:bold; color:"+ $scope.aryLv1[iRowspanLv1].FGC +"; ";
					}
					else{// アラートが設定されていると思われる
						sMeasNameBGColor = $scope.aryLv1[iRowspanLv1].BGC;
						sMeasureValueFont2 = " font-weight:normal; color:"+ sMeasFontColor +"; ";
					}
				}


				// Totalメジャー名 
				if( ( $scope.prop_nHeaderWidth2 > 0 && sMode1 == "grand" ) || ( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ) ){
					sHTML += "<td style='background-color:" + sMeasNameBGColor + "; border-left:3px double black; " 
						+ sSummaryLineBorderMeasName + sBdBottom3 +" text-align:"+sSummaryLineMeasNameAlign+"; "
						+ "' ><p style='" + sMeasureNameFont1 + " font-size:" + $scope.nMeasureLabelFontSize + "px; ' >";
					sHTML += $scope.layout.qHyperCube.qMeasureInfo[ iMeasureIndex1+iMCol1 ].qFallbackTitle;
					sHTML += "</p></td>";
//$scope.sDEBUG += " ( $scope.layout.qHyperCube.qMeasureInfo[ iMeasureIndex1+iMCol1 ].qFallbackTitle=" + $scope.layout.qHyperCube.qMeasureInfo[ iMeasureIndex1+iMCol1 ].qFallbackTitle + " / "; 
//$scope.sDEBUG += " sMeasureNameFont1=" + sMeasureNameFont1 + " ) "; 

					// Totalメジャー値
					sHTML += "<td " + sMeasBlink + " style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ " background-color:" + sMeasBGColor + "; ' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}
				else if( $scope.prop_nHeaderWidth2 > 0 && sMode1 != "grand" && $scope.prop_nMeasureCols == 1 ){
					// Totalメジャー値
					sHTML += "<td  " + sMeasBlink + " style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ " background-color:" + sMeasBGColor + "; ' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}
				else{
					// Totalメジャー値
					sHTML += "<td  " + sMeasBlink + " style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ " background-color:" + sMeasBGColor + "; ' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}


				// ハイパーキューブのメジャー値表示
				if( sMode1 == "grand" ){// グランド
					sHTML += $scope.layout.qHyperCube.qGrandTotalRow[ iMeasureIndex1 + iMCol1 ].qText;
				}
				else{// ディメンション
					sHTML += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iDim1][iMeasureIndex1+iMCol1+1].qText
				}
				sHTML += "</p></td>";
			} // <<< if( iMCol1 < $scope.prop_nRowBreak1 && iMeasureIndex1 +
			else{// お尻の半端セル
				//
				if( sMode1 == "grand" ){
					if( $scope.prop_nHeaderWidth2 > 0 ){
						sVLineMeasName4 = " border-left: 3px double black; "; // 縦罫線
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
					}
					else{
						sVLineMeasValue4 = " border-left: 3px double black; "; // 縦罫線
					}
				}
				else{// dimension
					if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){
						sVLineMeasName4 = " border-left: 3px double black; "; // 縦罫線
						sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
					}
					else{
						if( iMCol1==0 ){
							sVLineMeasValue4 = " border-left: 3px double black; "; // 縦罫線
						}
						else{
							sVLineMeasValue4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 
						}
					}
				}


				// お尻の半端　Totalメジャー名 
				if( ( $scope.prop_nHeaderWidth2 > 0 && sMode1 == "grand" ) || ( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ) ){
					sHTML += "<td style='border-left:3px double black; " + sSummaryLineBorderMeasName + sBdBottom3 +" text-align:"+sSummaryLineMeasNameAlign+"; "
						+ "' ><p style='" + sMeasureNameFont1 + " font-size:" + $scope.nMeasureLabelFontSize + "px; ' > ";
					sHTML += "</p></td>";

					// Totalメジャー値
					sHTML += "<td style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ "' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}
				else if( $scope.prop_nHeaderWidth2 > 0 && sMode1 != "grand" && $scope.prop_nMeasureCols == 1 ){
					// Totalメジャー値
					sHTML += "<td style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ "' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}
				else{
					// Totalメジャー値
					sHTML += "<td style=' text-align: right;  " + sSummaryLineBorderMeasValue + " " + sBdBottom3 + sVLineMeasValue4 
						+ "' ><p style='" + sMeasureValueFont2 + " font-size:" 
						+ $scope.layout.settings.nFontSize6 + "px;'>";
				}
				sHTML += "</p></td>";
			}

		}	// <<< for( var iMCol1 

		if( sMode1 == "grand" ){// グランドのみ表示
			// 真ん中お尻						
			sHTML += "<td style='width: 1px; border-left:1px solid black;'><p> </p></td>";
		}
		else{// ディメンションのみ表示
			// 右端お尻						
			sHTML += "<td style='width: 1px; border-left:1px solid black;'><p> </p></td>";
		}



//$scope.sDEBUG += " iMeasureIndex1+$scope.prop_nRowBreak1=" + (iMeasureIndex1 + $scope.prop_nRowBreak1) + " /";

						
		return sHTML;
	}

	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	function makeHTML2(){

		var sHTML ="";


	//$scope.sDEBUG += " ■$scope.prop_sTableMode=" + $scope.prop_sTableMode + " / ";
	//$scope.sDEBUG += " ■$scope.layout.qHyperCube.qDimensionInfo.length=" + $scope.layout.qHyperCube.qDimensionInfo.length + " / ";

		$element.css("overflow", "auto"); // スクロールバーを自動で表示

	//$scope.sDEBUG += " ウインドウサイズが知りたい " ;
	//$scope.sDEBUG += " $(window).width()=" + $window.innerWidth ;
	//$scope.sDEBUG += " $(window).height()=" + $(window).innerHeight() ;
	//				$(window).height();

		// ここからHTML
		sHTML = "<table style='empty-cells: hide; table-layout: fixed;  border-collapse: separate; border:0px solid #223333;'>";

		if( $scope.prop_sTableMode == "horizontal" ){

//$scope.sDEBUG += "■ディメンション１ $scope.layout.qHyperCube.qDimensionInfo.length=" + $scope.layout.qHyperCube.qDimensionInfo.length + " / ";
			if( $scope.layout.qHyperCube.qDimensionInfo.length < 2 ){// ディメンションが0か1っこの場合



				// ホライゾンモード
				// td のwidthは廃止されたのでcolgroupで列幅を調整する
				
				sHTML += "<colgroup>";
					if( $scope.prop_nHeaderWidth0 > 0 ){
						sHTML += "<col style='width: " + $scope.prop_nHeaderWidth0 + "px;' >";
					}
					if( $scope.prop_nHeaderWidth1 > 0 ){
						sHTML += "<col style='text-align:center; width: " + $scope.prop_nHeaderWidth1 + "px; ' >";
					}
					if( $scope.prop_nRowBreak1 > 1 ){
						for( var iMCol1=0 ; iMCol1 < $scope.prop_nRowBreak1 ; iMCol1++ ){
							if( $scope.prop_nHeaderWidth2 > 0  ){
								sHTML += "<col style='width: "+$scope.prop_nHeaderWidth2+"px; ' >";
							}
							sHTML += "<col style='width: "+$scope.prop_nHeaderWidth3+"px; ' >";
						}
					}
					else{
						if( $scope.prop_nHeaderWidth2 > 0 ){
							sHTML += "<col style=' width: " + $scope.prop_nHeaderWidth2 + "px; '>" 
						}
						// メジャー値
						sHTML += "<col style=' width: " + $scope.prop_nHeaderWidth3 + "px; ' >"
					}
					sHTML += "<col style='width: 5px; ' >";

					if( $scope.prop_nRowBreak1 > 1 ){// 改行する場合
						for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
							for( var iMCol1=0 ; iMCol1 < $scope.prop_nRowBreak1 ; iMCol1++ ){
								// メジャー名ヘッダ
								if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){
									sHTML += "<col style='width: "+$scope.prop_nHeaderWidth2+"px; ' >";
								}
								sHTML += "<col style='width: "+$scope.prop_nHeaderWidth3+"px; ' >";
							}
							sHTML += "<col style='width: 5px; ' >";
						}
					} // <<< if( $scope.prop_nRowBreak1 > 1 ){// 改行する場合
					else{
						for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
							if( $scope.prop_nHeaderWidth2 > 0 && $scope.prop_nMeasureCols >= 2 ){// メジャー名を出す場合
								sHTML += "<col style='width: "+$scope.prop_nHeaderWidth2+"px; ' >";
							}
							// メジャー値
							sHTML += "<col style='width: "+$scope.prop_nHeaderWidth3+"px; ' >";
							sHTML += "<col style='width: 1px; ' >";
						}
					}
				sHTML += "<col>";// dummy
				sHTML += "</colgroup>";


				// ヘッダ部分/////////////////////////////////////////////////////////////////////
				// 最上位ヘッダ。改行する場合のみ($scope.prop_nRowBreak1>=2)この処理が必要
				if( $scope.prop_nRowBreak1 >=2 ){
					sHTML += "<tr>";
					// グランド部分
					sHTML += makeTopHeader();
					// ディメンション部分
					for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
						sHTML += makeDimHeader( iDim1 );
					}
					sHTML += "</tr>";
				}


				// メジャーグループColSpan対応  /////////////////////////////////////////////////////////////////////
				if( $scope.prop_bUseColspan && $scope.prop_nRowBreak1>=2 ){
					sHTML += "<tr>";// Measure Groupのヘッダを作る
					sHTML += makeMeasureGroup( "grand"/*grand/dimension*/ );
					// ディメンション部分
					for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
						sHTML += makeMeasureGroup( "dimension"/*grand/dimension*/, iDim1 );
					}
					sHTML += "</tr>";
				}// <<<if( $scope.prop_bUseColspan ){

	
		
				// メジャーのヘッダ部分（通称２行目ヘッダ）	/////////////////////////////////////////////////////////////////////
				sHTML += "<tr>";
				// グランド部分
				sHTML += makeMeasureHeader( "grand"/*grand/dimension*/, 0 );
				// ディメンション部分
				if( $scope.aryDim1.length > 0 ){ // ディメンションがある
					if( $scope.prop_nRowBreak1 >=2 ){ // 改行される
						for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
							sHTML += makeMeasureHeader( "dimension"/*grand/dimension*/, iDim1 );
						}
					}
					else{
						for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
							sHTML += makeDimHeader( iDim1 );
						}
					}
				}
				else{// ディメンションがない
					for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
						sHTML += makeMeasureHeader( "dimension"/*grand/dimension*/, iDim1 );
					}
				}
				sHTML += "</tr>";


				// 本体/////////////////////////////////////////////////////////////////////
				for( var iMeasureIndex1=0, iCurrentRow1=0, iRowspanLv1=0, iRowspanLv2=0, iRangesumRowspanLv1=0, iRangesumRowspanLv2=0
					; iMeasureIndex1 < $scope.layout.qHyperCube.qMeasureInfo.length 
					; iMeasureIndex1 = iMeasureIndex1 + $scope.prop_nRowBreak1	// メジャーがインクリメントされる 
				){// メジャー分ループ
					sHTML += "<tr>";

					// 本体グランド部分
					sHTML += makeMatrix( "grand"/*grand/dimension*/, 0, iMeasureIndex1, iRowspanLv1, iRowspanLv2, iCurrentRow1, iRangesumRowspanLv1, iRangesumRowspanLv2 );
					
					
					// ディメンション部分
					for( var iDim1=0 ; iDim1 < $scope.aryDim1.length ; iDim1++ ){// ディメンション1のループ
						sHTML += makeMatrix( "dimension"/*grand/dimension*/, iDim1, iMeasureIndex1, iRowspanLv1, iRowspanLv2, iCurrentRow1, iRangesumRowspanLv1, iRangesumRowspanLv2 );
					}	



					// 一行分の作成終了
					// 大区分のインクリメント
					if( iRangesumRowspanLv2 < $scope.aryLv2[iRowspanLv2].RangesumRS ){
						iRangesumRowspanLv2 = $scope.aryLv2[iRowspanLv2].RangesumRS;
					}

					// 合計科目のインクリメント
					if( iRangesumRowspanLv1 < $scope.aryLv1[iRowspanLv1].RangesumRS ){
						iRangesumRowspanLv1 = $scope.aryLv1[iRowspanLv1].RangesumRS;
					}

					
					iCurrentRow1++ // 現在の行をインクリメントする
					// RowSpanをインクリメントする
					if( iCurrentRow1 >= $scope.aryLv1[iRowspanLv1].RangesumRS && iRowspanLv1 < $scope.aryLv1.length ){
						iRowspanLv1++;
					}
					if( iCurrentRow1 >= $scope.aryLv2[iRowspanLv2].RangesumRS && iRowspanLv2 < $scope.aryLv2.length ){
						iRowspanLv2++;
					}
					sHTML += "</tr>";

				} // <<< for( var iMeasureIndex1=0, iCurrentRow1					

			}	
			else if( $scope.layout.qHyperCube.qDimensionInfo.length == 2 ){// ディメンションが2この場合

			}

		}


		sHTML += "</table>";

		return sHTML;
	}
	// --------------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// この中で$scopeを使ってはいけない	
	function callbackCreateCube(reply,app2){

		secondHyperCube = reply.qHyperCube;

		console.log('Second HyperCube :', secondHyperCube);

	}
	// --------------------------------------------------------------------------------------------
	function addSecondCube( currApp ){

				{
					var i1 = 0;
//					$scope.sSUPERDEBUG += "■メジャー情報:"; 
					while( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){
//						$scope.sSUPERDEBUG += $scope.layout.qHyperCube.qMeasureInfo[ i1 ].qFallbackTitle + "=";
//						$scope.sSUPERDEBUG += $scope.layout.qHyperCube.qGrandTotalRow[ i1 ].qText + "// ";
						i1 = i1 + 1;
					}
				}

				////////////////////////////////////////////////////////////////////
				// ハイパーキューブを追加 /////////////////////////////////////////////
				
				// テーブルサンプルを見ろ　https://qlik.dev/libraries-and-tools/visualizations/table
				var qHyperCubeDef2 = {
					qDimensions : [],
					qMeasures : [
//						{ qDef : 
//							{	qDef : $scope.layout.qHyperCube.qMeasureInfo[ 0 ].qFallbackTitle //"M01"
//								//, qLabel : $scope.layout.qHyperCube.qMeasureInfo[ 0 ].qFallbackTitle //"M01の名前"
//							}
//						}
					],
					qInitialDataFetch: [
						{
							qWidth: 100,
							qHeight: 100
						}
					]
				};

				// ここをみろ https://help.qlik.com/en-US/sense-developer/April2020/Subsystems/Mashups/Content/Sense_Mashups/Create/Visualizations/Table/create-table.htm
				// JSONのメジャーにプッシュする
				{
					var i1 = 0;
					while( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){
						// qAttrExprInfo[0].qFallbackTitleの存在確認
						var sqAttrExprInfo0 = "='white'";
						var sqAttrExprInfo1 = "='black'";
						var sqAttrExprInfo2 = "='false'";
						if( typeof $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo == "undefined" ){
						}
						else{
							if( $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo.length >= 3 ){// BGcolor
								sqAttrExprInfo0 = $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo[0].qFallbackTitle;
							}
							if( $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo.length >= 3 ){// FontColor
								sqAttrExprInfo1 = $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo[1].qFallbackTitle;
							}
							if( $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo.length >= 3 ){// Blink
								sqAttrExprInfo2 = $scope.layout.qHyperCube.qMeasureInfo[i1].qAttrExprInfo[2].qFallbackTitle;
							}
						}
						// JSONのメジャーにプッシュするメジャー１ノード分
						qHyperCubeDef2.qMeasures.push( 
							{	
								"qDef": {
									"qDef": $scope.layout.qHyperCube.qMeasureInfo[ i1 ].qFallbackTitle
									, "qLabel" : $scope.layout.qHyperCube.qMeasureInfo[ i1 ].qFallbackTitle
								},
								"qAttributeExpressions": [
									{
									  "qExpression": sqAttrExprInfo0
									},
									{
									  "qExpression": sqAttrExprInfo1
									},
									{
									  "qExpression": sqAttrExprInfo2
									},
								]
							} 
						);
						i1 = i1 + 1;
					}
				}


				currApp.createCube(
					qHyperCubeDef2, callbackCreateCube
				);
				// <<< ハイパーキューブを追加 /////////////////////////////////////////////
				////////////////////////////////////////////////////////////////////


		return;
	}
	
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------
	// --------------------------------------------------------------------------------------------



				// --------------------------------------------------------------------------------------------
				$scope.mytable = function(){
$scope.sDEBUG = "";
$scope.sDEBUG +=  " ■ / ";



/*
// デバッグ用コード
$scope.sDEBUG = "丸野/";
$scope.sDEBUG += $scope.layout.visualization + "/";
// HELP https://help.qlik.com/en-US/sense-developer/June2020/Subsystems/EngineAPI/Content/Sense_EngineAPI/GenericObject/LayoutLevel/HyperCube.htm
var i2 = 0;
$scope.sDEBUG += "■ディメンション情報:"; 
while( i2 < $scope.layout.qHyperCube.qDimensionInfo.length ){
	$scope.sDEBUG += $scope.layout.qHyperCube.qDimensionInfo[ i2 ].qFallbackTitle + "/";
		i2 = i2 + 1;
}
var i1 = 0;
$scope.sDEBUG += "■メジャー情報:"; 
while( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){
	$scope.sDEBUG += $scope.layout.qHyperCube.qMeasureInfo[ i1 ].qFallbackTitle + "=";
	$scope.sDEBUG += $scope.layout.qHyperCube.qGrandTotalRow[ i1 ].qText + "// ";
	i1 = i1 + 1;
}

var ix1,iy1;
$scope.sDEBUG += "■マトリックス情報:  "; 
iy1 = 0;
while( iy1 < $scope.layout.qHyperCube.qSize.qcy ){// ディメンションのループ
	$scope.sDEBUG += " ｛ iy1:"+iy1+"  "; 
	ix1=0; // ix1 が 0 の位置がヘッダ行だと思えばよい。	
	while( ix1 < $scope.layout.qHyperCube.qSize.qcx ){// メジャーのループ
		$scope.sDEBUG += " ( ix1="+ix1+"  "; 
		$scope.sDEBUG += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][ix1].qText + " )   ";
		ix1 = ix1 + 1;
	}
	$scope.sDEBUG += " ｝ "; 
	iy1 = iy1 + 1;
}
*/
					


				
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					var sHTML="";

//$scope.sDEBUG += "■プロパティを配列にする / "; 

					// プロパティを配列にする					
					setPropAry();

					// 新バージョン
					sHTML += makeHTML2(); 

// var comp = $compile('<button ng-click="onclickMaru(222)">Teste</button>')($scope);
//  angular.element(document.querySelector('#content')).append(comp);
//return /*$sce.trustAsHtml(comp[0].outerHTML)*/"";
//sHTML += "<button class='lui-button' (click)='alert(111)' style='font-size:24px; color:black; height:28px;' >(click)</button> ";
//sHTML += "<button class='lui-button' ng-click='onclickMaru(222)' style='font-size:24px; color:black; height:28px;' >ng-click</button> ";
//sHTML += "<button class='lui-button' (click)='onclickMaru(111)' style='font-size:24px; color:black; height:28px;' >(click)</button> ";
//sHTML += "<button class='lui-button' ng-click='alert(222)' style='font-size:24px; color:black; height:28px;' >ng-click</button> ";
//sHTML += "<button class='button' onclick='onclickMaru(555)' style='font-size:24px; color:black; height:28px;' >Alert()</button> ";
//sHTML += "<button class='button' onclick='alert(567)' style='font-size:24px; color:black; height:28px;' >Alert()</button> ";
//sHTML += "<button class='lui-button' onclick='alert(666)' style='font-size:24px; color:black; height:28px;' >onclick()</button> ";
//sHTML += "<button class='lui-button' onclick='alert(777)' style='font-size:24px; color:black; height:28px;' >lui-button</button> ";
//sHTML = $sce.trustAsHtml(sHTML);// buttonタグがサニタイズされないように信頼済みとマークする
//$scope.sDEBUG = sHTML;

					return sHTML ;	// VIEWにHTMLを戻す
				}// <<<$scope.mytable = function
				
				// --------------------------------------------------------------------------------------------
				<!-- $scopeは、HTMLのテンプレートとcontrollerの橋渡しをする。 -->
//				$scope.maruno = "丸野" + "/"; // 宣言もなく、好きなように変数をつけていい。ここではmarunoという変数を付けた。HTMLのテンプレートから{{で囲めば}}直接アクセスできる
			}]	// <<<controller: ['
		
        };	// <<<return
    } // <<<function ( qlik , template , props )
);	// <<<define


