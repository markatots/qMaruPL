// # Author
// Katsuaki Maruno
// 
// # Copyright
// Copyright ©2021 OTSUKA CORPORATION
// 
// # License
// The source code is licensed MIT. The website content is licensed CC BY 4.0,see LICENSE.

define( [ "qlik" , 'text!./maruTemplate.html' , './maruProperties' ],
    function ( qlik , template , props ) {
        'use strict';

        return {
			definition: props,



			
			snapshot: {canTakeSnapshot: true},
			
			initialProperties: {
				qHyperCubeDef: {
					qDimensions: [],
					qMeasures: [],
					qInitialDataFetch: [
						{
							qWidth: 100,
							qHeight: 100
						}
					]
				}
			},
			
			template: template,
			// 参考：https://www.buildinsider.net/web/angularjstips/0007
			controller: ['$scope', '$sce', function( $scope , $sce ) {

				console.log('layout', $scope.layout); // この一行入れると大変役立つ。Chrome→縦三点リーダ→その他のツール→デベロッパーツール→で、オブジェクトの中身を確認できます 
				console.log('scope', $scope); // この一行入れると大変役立つ。Chrome→縦三点リーダ→その他のツール→デベロッパーツール→で、オブジェクトの中身を確認できます 


				// マウスボタンが押されると、この onclickMaru が呼ばれます
				$scope.onclickMaru = function( s1 ){
							alert(s1);
//							qlik.currApp().variable.setContent("vTest", $scope.moji1);
					// ヘルプはここ https://help.qlik.com/en-US/sense-developer/May2021/Subsystems/APIs/Content/Sense_ClientAPIs/CapabilityAPIs/NavigationAPI/gotoSheet-method.htm
					qlik.navigation.gotoSheet(s1);
				}

				// --------------------------------------------------------------------------------------------
				$scope.sanitize = function(){
					var sHTML , sHTML2 ;
					sHTML = "<h1>あああ</h1><hr>";
					sHTML2 = "<table border=1><tr><td>A</td><td>い</td></tr></table>";
//					sHTML2 = $sce.trustAsHtml(sHTML2);// buttonタグがサニタイズされないように信頼済みとマークする
					return sHTML + sHTML2 ;
				
				}



				// 文字列のTrue、FalseをBooelanで返す。
				function myBoolCast( s999 ){
					var s1000;
					s1000 = String(s999).toLowerCase();
					if( s1000 == "true" )
						return true;
					else
						return false;
				}


				// プロパティの値を構造体配列にする
				function setPropAry(){
					$scope.aryLv1=[];
					$scope.aryLv2=[];
				
					// --------------------------------------------------------------------------
					var sPattern1 = new RegExp(/^[-]?([1-9]\d*|0)(\.\d+)?$/); // 正規表現で数値入力チェックする
					var sPattern2 = new RegExp(/[0-9A-Za-z#]+/); // 正規表現でカラー表示チェックする


					let oLv1;
					
					// Lv1 グループ====================================================
					
					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan1 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName1 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align1 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign1 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC1 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC1 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary1 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut1 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink1 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );

					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan2 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName2 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align2 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC2 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC2 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary2 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut2 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink2 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan3 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName3 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align3 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign3 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC3 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC3 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary3 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut3 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink3 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan4 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName4 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align4 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign4 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC4 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC4 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary4 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut4 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink4 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan5 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName5 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align5 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC5 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC5 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary5 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut5 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink5 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan6 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName6 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align6 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign6 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC6 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC6 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary6 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut6 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink6 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan7 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName7 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align7 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign7 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC7 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC7 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary7 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut7 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink7 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan8 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName8 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align8 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign8 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC8 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC8 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary8 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut8 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink8 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan9 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName9 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align9 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign9 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC9 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC9 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary9 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut9 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink9 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan10 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName10 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align10 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign10 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC10 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC10 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary10 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut10 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink10 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan11 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName11 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align11 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign11 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC11 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC11 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary11 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut11 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink11 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan12 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName12 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align12 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign12 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC12 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC12 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary12 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut12 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink12 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan13 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName13 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align13 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign13 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC13 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC13 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary13 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut13 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink13 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan14 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName14 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align14 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign14 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC14 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC14 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary14 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut14 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink14 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan15 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName15 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align15 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign15 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC15 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC15 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary15 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut15 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink15 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan16 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName16 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align16 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign16 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC16 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC16 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary16 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut16 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink16 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					// 
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv1Rowspan17 );
					oLv1.RowName = String( $scope.layout.settings.sLv1RowName17 );
					oLv1.Align = String( $scope.layout.settings.sLv1Align17 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv1VertiAlign17 );
					oLv1.BGC = String( $scope.layout.settings.sLv1BGC17 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv1FGC17 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv1Summary17 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv1StandOut17 );
					oLv1.Blink = myBoolCast( $scope.layout.settings.sLv1Blink17 );
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );

					
					// fin
					oLv1 = new Object();
					oLv1.Rowspan = 100;
					oLv1.RowName = "　";
					oLv1.Align = "center";
					oLv1.VertiAlign = "middle";
					oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = "#111111" ;
					oLv1.Summary = false;
					oLv1.StandOut = false;
					oLv1.Blink = "false";
					oLv1.RangesumRS = 0;
					$scope.aryLv1.push( oLv1 );
					
					var nRageSum1 = 0;
//$scope.sDEBUG += " $scope.aryLv1.length=" + $scope.aryLv1.length +" /";
//$scope.sDEBUG += " Boolean=" + myBoolCast(true) +" /";
					for( var i1=0 ; i1 < $scope.aryLv1.length ; i1++ ){
						nRageSum1 += $scope.aryLv1[i1].Rowspan;
						$scope.aryLv1[i1].RangesumRS = nRageSum1;
//$scope.sDEBUG += " $scope.aryLv1[i1].Rowspan=" + $scope.aryLv1[i1].Rowspan 
	+ " $scope.aryLv1[i1].RowName=" + $scope.aryLv1[i1].RowName 
	+ " $scope.aryLv1[i1].RangesumRS=" + $scope.aryLv1[i1].RangesumRS + " /";
					}



					// Lv2 グループ====================================================
					
					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv2Rowspan1 );
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName1 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align1 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign1 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC1 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC1 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary1 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut1 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv2Rowspan2 );
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName2 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align2 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign2 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC2 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC2 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary2 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut2 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv2Rowspan3 );
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName3 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align3 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign3 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC3 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC3 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary3 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut3 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv2Rowspan4 );
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName4 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align4 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign4 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC4 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC4 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary4 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut4 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					//
					oLv1 = new Object();
					oLv1.Rowspan = parseInt( $scope.layout.settings.sLv2Rowspan5 );
					oLv1.RowName = String( $scope.layout.settings.sLv2RowName5 );
					oLv1.Align = String( $scope.layout.settings.sLv2Align5 );
					oLv1.VertiAlign = String( $scope.layout.settings.sLv2VertiAlign5 );
					oLv1.BGC = String( $scope.layout.settings.sLv2BGC5 );
						if( ! sPattern2.test( oLv1.BGC ) ) oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = String( $scope.layout.settings.sLv2FGC5 );
						if( ! sPattern2.test( oLv1.FGC ) ) oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( $scope.layout.settings.sLv2Summary5 );
					oLv1.StandOut = myBoolCast( $scope.layout.settings.sLv2StandOut5 );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );

					// lv2 fin
					oLv1 = new Object();
					oLv1.Rowspan = 1000;
					oLv1.RowName = "　";
					oLv1.Align = "center";
					oLv1.VertiAlign = "middle";
					oLv1.BGC = "#EEEEEE" ;
					oLv1.FGC = "#111111" ;
					oLv1.Summary = myBoolCast( false );
					oLv1.StandOut = myBoolCast( false );
					oLv1.Blink = myBoolCast( false );
					oLv1.RangesumRS = 0;
					$scope.aryLv2.push( oLv1 );


					nRageSum1 = 0;
//$scope.sDEBUG += " $scope.aryLv2.length=" + $scope.aryLv2.length +" /";
//$scope.sDEBUG += " Boolean=" + myBoolCast(false) +" /";
					for( var i1=0 ; i1 < $scope.aryLv2.length ; i1++ ){
						nRageSum1 += $scope.aryLv2[i1].Rowspan;
						$scope.aryLv2[i1].RangesumRS = nRageSum1;
//$scope.sDEBUG += " $scope.aryLv2[i1].Rowspan=" + $scope.aryLv2[i1].Rowspan 
	+ " $scope.aryLv2[i1].RowName=" + $scope.aryLv2[i1].RowName 
	+ " $scope.aryLv2[i1].RangesumRS=" + $scope.aryLv2[i1].RangesumRS + " /";
					}


					return "いいいいいtrue";
				}// <<<$scope.setPropAry = function()
				
				
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				// --------------------------------------------------------------------------------------------
				function makeHTML(){
					var i1 = 0; // メジャーのインデックス
					var iCurrentRow1 = 0; // 現在の行
					var i2 = 0;
					var i2b = 0;
					var i3 = 0;
					var i3b = 0;
					var sHTML ="";
					
					var sWidthPxThickest = "4";
					var sHeaderLineColor = "darkgray";

					// どうもプロパティのデータ型を信用できない・・・
					var prop_nMeasureCols = 1;
					if( $scope.layout.settings.bRepeatName == true){
						prop_nMeasureCols = 2;
					}

					var prop_nRowBreak1 = parseInt( $scope.layout.settings.nRowBreak1 );
					if( prop_nRowBreak1 >= 5 )
						prop_nRowBreak1 = 5;
					else if( prop_nRowBreak1 <=0 )
						prop_nRowBreak1 = 0;

					var prop_nHeaderWidth0 = parseInt( $scope.layout.settings.sHeaderWidth0 );
					var prop_nHeaderWidth1 = parseInt( $scope.layout.settings.sHeaderWidth1 );
					var prop_nHeaderWidth2 = parseInt( $scope.layout.settings.sHeaderWidth2 );
					var prop_nHeaderWidth3 = parseInt( $scope.layout.settings.sHeaderWidth3 );

					var prop_nDimHeaderWidth1 = parseInt( $scope.layout.settings.sDimHeaderWidth1 );

					var sWritingMode1;// 縦書きか否か
					if( myBoolCast( $scope.layout.settings.bLv2WritingMode ) ){
						sWritingMode1 = "writing-mode: vertical-rl; display: inline-block; ";
					}else{sWritingMode1="";}


					var prop_TopTotalHeaderText = $scope.layout.settings.sHeaderTextTopTotal;
					var prop_aryTotalHeaderText = [];
					prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderText3 );
					prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal2 );
					prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal3 );
					prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal4 );
					prop_aryTotalHeaderText.push( $scope.layout.settings.sHeaderTextTotal5 );



					// ここからHTML
					sHTML = "<table style='empty-cells: hide; table-layout: fixed;  border-collapse: separate; border:0px solid #223333;'>";

					// td のwidthは廃止されたのでcolgroupで列幅を調整する
					sHTML += "<colgroup>";
						if( prop_nHeaderWidth0 > 0 ){
							sHTML += "<col style='width: " + prop_nHeaderWidth0 + "px;' >";
						}
						if( prop_nHeaderWidth1 > 0 ){
							sHTML += "<col style='text-align:center; width: " + prop_nHeaderWidth1 + "px; ' >";
						}
						if( prop_nRowBreak1 > 1 ){
							for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 ; iMCol1++ ){
								if( prop_nHeaderWidth2 > 0  ){
									sHTML += "<col style='width: "+prop_nHeaderWidth2+"px; ' >";
								}
								sHTML += "<col style='width: "+prop_nHeaderWidth3+"px; ' >";
							}
						}
						else{
							if( prop_nHeaderWidth2 > 0 ){
								sHTML += "<col style=' width: " + prop_nHeaderWidth2 + "px; '>" 
							}
							// メジャー値
							sHTML += "<col style=' width: " + prop_nHeaderWidth3 + "px; ' >"
						}
						sHTML += "<col style='width: 5px; ' >";
						if( prop_nRowBreak1 > 1 ){// 改行する場合
							for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 ; iMCol1++ ){
								var iy1=0;
								while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
							
//									if( prop_nRowBreak1 > 1 && prop_nMeasureCols >= 2 ){// 改行する場合のみ項目名をリピート
										// メジャー名ヘッダ
//										if( prop_nHeaderWidth2 > 0 ){
											if( prop_nMeasureCols >= 2 ){
												sHTML += "<col style='width: "+prop_nHeaderWidth2+"px; ' >";
											}
//										}
										sHTML += "<col style='width: "+prop_nHeaderWidth3+"px; ' >";
//									}
									iy1 = iy1 + 1;
								}
							}
						}
						else{
							var iy1=0;
							while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
								if( prop_nHeaderWidth2 > 0 ){
									if( prop_nMeasureCols >= 2 ){
										sHTML += "<col style='width: "+prop_nHeaderWidth2+"px; ' >";
									}
								}
								sHTML += "<col style='width: "+prop_nHeaderWidth3+"px; ' >";
								iy1 = iy1 + 1;
							}
						}
					sHTML += "<col>";// dummy
					sHTML += "</colgroup>";


					// ヘッダ部分
					// 最上位ヘッダ。改行する場合のみ(>=2)必要
					if( prop_nRowBreak1 > 1 ){
						sHTML += "<tr>";

						// Lv2
						if( prop_nHeaderWidth0 > 0 ){
							sHTML += "<td style='width: " + prop_nHeaderWidth0 + "px;' > </td>";
						}
						// Lv1
						if( prop_nHeaderWidth1 > 0 ){
							sHTML += "<td style='text-align:center; width: " + prop_nHeaderWidth1 + "px; '> </td>";
						}
						// ヘッダ列ループ prop_nRowBreak1
//						for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 ; iMCol1++ ){
							if( prop_nHeaderWidth2 > 0 ){
								// メジャーのセット
								sHTML += "<td colspan=" + (2 * prop_nRowBreak1) + " bgcolor=" + $scope.layout.settings.sHeaderBGC1 
									+ " style='text-align:center; width: " + ( prop_nHeaderWidth2 + prop_nHeaderWidth3 ) * prop_nRowBreak1
									+ "px; border: 1px solid "+sHeaderLineColor+"; ' ><p style='font-weight:bold; color:"
									+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>"+prop_TopTotalHeaderText+"</p></td>"; 
							}
							else{
								// メジャーのセット
								sHTML += "<td colspan=" + (1 * prop_nRowBreak1) + " bgcolor=" + $scope.layout.settings.sHeaderBGC1 
									+ " style='text-align:center; width: " + ( prop_nHeaderWidth2 + prop_nHeaderWidth3 ) * prop_nRowBreak1
									+ "px; border: 1px solid "+sHeaderLineColor+"; ' ><p style='font-weight:bold; color:"
									+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>"+prop_TopTotalHeaderText+"</p></td>"; 
							}
//						}	// <<< for( var iMCol1 
						sHTML += "<td style='width: 0px; ' ></td>";

						// ディメンションヘッダ
						// ディメンションのヘッダが続くsDimHeaderWidth1
						var iy1;
						iy1 = 0;
						var sColSpan22 = "";
						if( prop_nRowBreak1 > 1  ){// 改行する場合、かつ、項目び幅が０じゃない場合、のみColSpan変更
							if( prop_nHeaderWidth2 > 0 ){
								sColSpan22 = " colspan=" + (prop_nRowBreak1 * prop_nMeasureCols ) + " ";
							}
							else{
								sColSpan22 = " colspan=" + (prop_nRowBreak1  ) + " ";
							}
						}
						while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
							sHTML += "<td " + sColSpan22 + " bgcolor=" + $scope.layout.settings.sHeaderBGC2 
								+ " style='text-align:center; width: " +  ( prop_nRowBreak1 * ( prop_nDimHeaderWidth1 + (prop_nMeasureCols-1)*prop_nHeaderWidth2 ) ) 
								+ "px; border-right: 0px solid "+sHeaderLineColor+";  border-left: "+sWidthPxThickest+"px double "+sHeaderLineColor+";  border-top: 1px solid "+sHeaderLineColor+";  border-bottom: 1px solid "+sHeaderLineColor+";  '><p style='font-weight:bold; color:"
								+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>";
							sHTML += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText;
							sHTML += "</p></td>";
							iy1 = iy1 + 1;
						}
						sHTML += "<td></td>";// dummy
						sHTML += "</tr>";
						sHTML += "</tr>";
					}

					sHTML += "<tr>";
					
					// 2行目ヘッダ
					// Lv2
					if( prop_nHeaderWidth0 > 0 ){
						sHTML += "<td  bgcolor=" + $scope.layout.settings.sHeaderBGC1 
							+ " style='text-align:center; width: " + prop_nHeaderWidth0 + "px; border:1px solid "+sHeaderLineColor+";'><p style='font-weight:bold; color:" 
							+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText0
							+ "</p></td>";
					}
					// Lv1
					if( prop_nHeaderWidth1 > 0 ){
						sHTML += "<td  bgcolor=" + $scope.layout.settings.sHeaderBGC1 
							+ " style='text-align:center; width: " + prop_nHeaderWidth1 + "px; border:1px solid "+sHeaderLineColor+";'><p style='font-weight:bold; color:" 
							+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText1
							+ "</p></td>";
					}

//$scope.sDEBUG += " nRowBreak1=" + prop_nRowBreak1 + " /";
//$scope.sDEBUG += " sHeaderWidth2=" + prop_nHeaderWidth2 + " /";
//$scope.sDEBUG += " sHeaderWidth3=" + prop_nHeaderWidth3 + " /";
					
					// ヘッダ列ループ nRowBreak1
					for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 ; iMCol1++ ){
						// メジャー名
						if( prop_nHeaderWidth2 > 0 ){
							sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC1 
								+ " style='text-align:center; width: " + prop_nHeaderWidth2 
								+ "px; border-left:3px double "+sHeaderLineColor+"; border-top:1px solid "+sHeaderLineColor+"; border-right:1px double "+sHeaderLineColor+"; border-bottom:1px solid "+sHeaderLineColor+";'>" 
								+ "<p style='font-weight:bold; color:" 
								+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText2
								+ "</p></td>";
						}
						// メジャー値
						sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC2 
							+ " style='text-align:center; width: " + prop_nHeaderWidth3 
							+ "px; border-left:1px solid "+sHeaderLineColor+"; border-top:1px solid "+sHeaderLineColor+"; border-right:1px solid "+sHeaderLineColor+"; border-bottom:1px solid "+sHeaderLineColor+"; '>"
							+ "<p style='font-weight:bold; color:" 
							+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + prop_aryTotalHeaderText[iMCol1] + "</p></td>";
						
					}	// <<< for( var iMCol1 
					
					// 右端お尻						
					sHTML += "<td style='width: 5px; border:1px solid black;'></td>";

/*
					// ディメンションのヘッダが続くsDimHeaderWidth1
					var iy1;
					iy1 = 0;
					
					var sColSpan22 = "";
					if( prop_nRowBreak1 > 1 ){// 改行する場合のみColSpan変更
						sColSpan22 = " colspan=" + (prop_nRowBreak1 * prop_nMeasureCols ) + " ";
					}
					
					while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
						sHTML += "<td " + sColSpan22 + " bgcolor=" + $scope.layout.settings.sHeaderBGC2 
							+ " style='text-align:center; width: " + prop_nDimHeaderWidth1 
							+ "px; border: 1px solid black; '><p style='font-weight:bold; color:"
							+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>";
						sHTML += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText;
						sHTML += "</p></td>";
						
						
						iy1 = iy1 + 1;
					}
					sHTML += "<td></td>";// dummy
					sHTML += "</tr>";
*/

					// ディメンションのヘッダが続くsDimHeaderWidth1
					// ヘッダ列ループ nRowBreak1
					var iy1;
					iy1 = 0;
					while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
						for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 ; iMCol1++ ){
if( prop_nRowBreak1 > 1 ){// 改行する場合
							if( prop_nRowBreak1 > 1 && prop_nMeasureCols >= 2 ){// 改行する場合のみ項目名をリピート
								// メジャー名ヘッダ
								if( prop_nHeaderWidth2 > 0 ){
									if( iMCol1 == 0 ){// ディメンションの切り替えでは2重太線
										sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC1 
											+ " style='text-align:center; width: " + prop_nHeaderWidth2 
											+ "px; border-left:"+sWidthPxThickest+"px double "+sHeaderLineColor+"; border-top:1px solid black; border-right:1px double black; border-bottom:1px solid black;'>" 
											+ "<p style='font-weight:bold; color:" 
											+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText2
											+ "</p></td>";
									}
									else{
										sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC1 
											+ " style='text-align:center; width: " + prop_nHeaderWidth2 
											+ "px; border-left:3px double "+sHeaderLineColor+"; border-top:1px solid black; border-right:1px double black; border-bottom:1px solid black;'>" 
											+ "<p style='font-weight:bold; color:" 
											+ $scope.layout.settings.sHeaderFGC1 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + $scope.layout.settings.sHeaderText2
											+ "</p></td>";
									}
								}
							}
							
							if( iMCol1 == 0 && prop_nMeasureCols == 1 ){// ディメンションの切り替えでなおかつ、メジャー項目が隠されている場合は、メジャー値が 2重太線
								// メジャー値ヘッダ
								sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC2 
									+ " style='text-align:center; width: " + prop_nHeaderWidth3 
									+ "px; border-left:"+sWidthPxThickest+"px double "+sHeaderLineColor+"; border-top:1px solid black; border-right:3px double black; border-bottom:1px solid black; '>"
									+ "<p style='font-weight:bold; color:" 
									+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + prop_aryTotalHeaderText[iMCol1] + "</p></td>";
							}
							else{
								// メジャー値ヘッダ
								sHTML += "<td bgcolor=" + $scope.layout.settings.sHeaderBGC2 
									+ " style='text-align:center; width: " + prop_nHeaderWidth3 
									+ "px; border-left:1px solid black; border-top:1px solid black; border-right:3px double black; border-bottom:1px solid black; '>"
									+ "<p style='font-weight:bold; color:" 
									+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize5 + "px; '>" + prop_aryTotalHeaderText[iMCol1] + "</p></td>";
							}
}
else{
								while( iy1 < $scope.layout.qHyperCube.qSize.qcy  && $scope.layout.qHyperCube.qSize.qcy>=2 ){
									sHTML += "<td  bgcolor=" + $scope.layout.settings.sHeaderBGC2 
										+ " style='text-align:center; width: " + prop_nDimHeaderWidth1 
										+ "px; border: 1px solid black; '><p style='font-weight:bold; color:"
										+ $scope.layout.settings.sHeaderFGC2 + "; font-size:" + $scope.layout.settings.nFontSize4 + "px; '>";
									sHTML += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][0].qText;
									sHTML += "</p></td>";


									iy1 = iy1 + 1;
								}
								sHTML += "<td></td>";// dummy
								sHTML += "</tr>";
}


						}	// <<< for( var iMCol1 
						iy1 = iy1 + 1;
					}



					// 本体
					i1=0;
					while( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){// メジャー分ループ
//$scope.sDEBUG += " i1=" + i1 + " /";

						var sBdBottom3="";
						if( $scope.layout.settings.sLineHorizon1 == "none" ){// 横罫線
							sBdBottom3 = ""; // 横罫線
						}
						else{
							sBdBottom3 = " border-bottom: 1px " + $scope.layout.settings.sLineHorizon1 + " black; "; // 横罫線
						}
						
						

						if( iCurrentRow1 == $scope.layout.qHyperCube.qMeasureInfo.length -1 || iCurrentRow1 == $scope.aryLv1[i2].RangesumRS-1 /*|| i3-1==iCurrentRow1*/ ){// アンダーラインが絶対に必要
							sBdBottom3 = " border-bottom:1px solid black; ";
						}
						
						
						sHTML += "<tr>";





						// 大区分
						if( i3b < $scope.aryLv2[i2b].RangesumRS ){
							if( prop_nHeaderWidth0 > 0 ){
								sHTML += "<td rowspan=" + $scope.aryLv2[i2b].Rowspan + " bgcolor=" + $scope.aryLv2[i2b].BGC ;
								sHTML +=  " style='text-align:" + $scope.aryLv2[i2b].Align + "; border-left:1px solid black; border-top:1px solid black; border-right:1px solid black; border-bottom:1px solid black;" ;
								sHTML +=  " vertical-align:"+ $scope.aryLv2[i2b].VertiAlign ;
								sHTML +=  "; '><p style='" + sWritingMode1 + " padding:0px 0px 0px 0px; font-weight:bold; font-size:" ;
								sHTML +=  $scope.layout.settings.nFontSize1 + "px; color:"+ $scope.aryLv2[i2b].FGC +"' >" ;
								sHTML +=  $scope.aryLv2[i2b].RowName +"</p></td>" ;
							}
							i3b = $scope.aryLv2[i2b].RangesumRS;
						}

						// 点滅条件
						var sBlink="";
						if( $scope.aryLv1[i2].Blink ){
							sBlink = " class='blink' ";
						}

						// 合計科目
						if( i3 < $scope.aryLv1[i2].RangesumRS ){
							if( prop_nHeaderWidth1 > 0 ){
								sHTML += "<td "+ sBlink +" rowspan=" + $scope.aryLv1[i2].Rowspan + " bgcolor=" + $scope.aryLv1[i2].BGC ;
								sHTML += " style='text-align:" + $scope.aryLv1[i2].Align + "; border-left:1px solid black; border-top:1px solid black; border-bottom:1px solid black; border-right:1px solid black; " ;
								sHTML +=  " vertical-align:"+ $scope.aryLv1[i2].VertiAlign ;
								sHTML +=  ";'><p style='font-weight:bold; font-size:" + $scope.layout.settings.nFontSize1 + "px; color:"+ $scope.aryLv1[i2].FGC +"' >" ;
								sHTML +=  $scope.aryLv1[i2].RowName +"</p></td>";
							}
							i3 = $scope.aryLv1[i2].RangesumRS;
						}
						
						var sSummaryLine,sSummaryLineb,sFont2;// 合計行の場合に特別な色合いaryStandOut
						sSummaryLine="";
						sFont2="";
						sSummaryLineb=" text-align: right; ";
						
						// 最終行の場合は下に線
						if( i1 + prop_nRowBreak1 >= $scope.layout.qHyperCube.qMeasureInfo.length ){
							sSummaryLine = " border-bottom:1px solid black; ";
							sSummaryLineb = " text-align: right; border-bottom:1px solid black; ";
						}
						
						if( $scope.aryLv1[i2].Summary ){// 横線
							sSummaryLine = " border-top:1px solid black; border-bottom:1px solid black; ";
							sSummaryLineb = " text-align: right; border-top:1px solid black; border-bottom:1px solid black; ";
						}

						if( $scope.aryLv1[i2].StandOut ){// 色帯＋太字
							sSummaryLine += "background-color:" + $scope.aryLv1[i2].BGC + "; ";
							sSummaryLineb += "background-color:" + $scope.aryLv1[i2].BGC + "; ";
							sFont2 = "font-weight:bold; color:"+ $scope.aryLv1[i2].FGC +"; ";
						}
						
						var sVLine4;// 縦罫線の種類
						if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
							sVLine4 = ""; // 縦罫線
						}
						else{
							sVLine4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 縦罫線
						}
						
						// 中身列ループ prop_nRowBreak1
						for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 && i1 + iMCol1 < $scope.layout.qHyperCube.qMeasureInfo.length ; iMCol1++ ){
							// Totalメジャー名
							if( prop_nHeaderWidth2 > 0 ){
								sHTML += "<td style='border-left:3px double black; " + sSummaryLine + sBdBottom3 
									+ "' ><p style='" + sFont2 + " font-size:" + $scope.layout.settings.nFontSize2 + "px; ' >";
								sHTML += $scope.layout.qHyperCube.qMeasureInfo[ i1+iMCol1 ].qFallbackTitle;
								sHTML += "</p></td>";
							}
							// Totalメジャー値
							sHTML += "<td style='border-right:3px double black; " + sSummaryLineb + " border-right:1px solid black;" + sBdBottom3 + sVLine4 
								+ "' ><p style='" + sFont2 + " font-size:" 
								+ $scope.layout.settings.nFontSize6 + "px;'>";
							sHTML += $scope.layout.qHyperCube.qGrandTotalRow[ i1 + iMCol1 ].qText;
							sHTML += "</p></td>";
							
						}	// <<< for( var iMCol1 
						
						// お尻の半端セルを付ける
						if( ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 ) >0 )//余りがでる場合
						if( i1 + prop_nRowBreak1 >= $scope.layout.qHyperCube.qMeasureInfo.length ){
//$scope.sDEBUG += " ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 )=" + (($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 )) + " /";
							for( var i45 = 0 ; prop_nRowBreak1 > 1 && i45 < prop_nRowBreak1 - ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 ) ; i45++ ){
								if( prop_nHeaderWidth2 > 0 ){
									sHTML += "<td style='border-left:3px double black; border-bottom: 1px solid black; ><pstyle='" + sFont2 + " font-size:" 
										+ $scope.layout.settings.nFontSize2 + "px; '> </p></td>";
								}
								sHTML += "<td style='border-right:1px double black; border-bottom: 1px solid black; ><p style='" + sFont2 + " font-size:" 
									+ $scope.layout.settings.nFontSize6 + "px;'> </p></td>";
							}
						}
						
						sHTML += "<td></td>";
						
						// 中身列ループ prop_nRowBreak1
						var iy1;// ディメンションを連続
						iy1 = 0;
						while( iy1 < $scope.layout.qHyperCube.qSize.qcy && $scope.layout.qHyperCube.qSize.qcy>=2 ){
							for( var iMCol1=0 ; iMCol1 < prop_nRowBreak1 && i1 + iMCol1 < $scope.layout.qHyperCube.qMeasureInfo.length ; iMCol1++ ){
								if( iy1 == $scope.layout.qHyperCube.qSize.qcy -1 && iMCol1 == prop_nRowBreak1 -1 ){
									sVLine4 += "border-right: 1px solid black; "; // 一番右の列にボーダーを入れる
								}
								
								if( prop_nRowBreak1 > 1 && prop_nMeasureCols >= 2 ){// 改行する場合のみ項目名をリピート
									if( prop_nHeaderWidth2 > 0 ){// 項目名
										if( iMCol1==0 ){
											sHTML += "<td style='border-left:"+sWidthPxThickest+"px double black; " + sSummaryLine + sBdBottom3 
												+ "' ><p style='" + sFont2 + " font-size:" + $scope.layout.settings.nFontSize2 + "px; '>";
										}
										else{
											sHTML += "<td style='border-left:3px double black; " + sSummaryLine + sBdBottom3 
												+ "' ><p style='" + sFont2 + " font-size:" + $scope.layout.settings.nFontSize2 + "px; '>";
										}
										sHTML += $scope.layout.qHyperCube.qMeasureInfo[ i1+iMCol1 ].qFallbackTitle;
										sHTML += "</p></td>";
									}
								}
								else if( iMCol1 == 0 ){
									sVLine4 += " border-left:"+sWidthPxThickest+"px double black; ";
								}
								else{
									sVLine4 += " border-left:3px double black; ";
								}

//$scope.sDEBUG += " sSummaryLine=" + (sSummaryLine) + " /";
//$scope.sDEBUG += " sBdBottom3=" + (sBdBottom3) + " /";
//$scope.sDEBUG += " sVLine4=" + (sVLine4) + " /";

								// 項目値
								sHTML += "<td style='text-align: right; " + sSummaryLine + sBdBottom3 + sVLine4 + "' ><p style='" + sFont2 
								+ " font-size:" + $scope.layout.settings.nFontSize3 + "px; '>";
								sHTML += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[ iy1 ][ i1 + iMCol1 + 1 ].qText;
								sHTML += "</p></td>";

								

							}	// <<< for( var iMCol1 
							
							
							// お尻の半端セルを付ける
							if( ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 ) >0 )//余りがでる場合
							if( i1 + prop_nRowBreak1 >= $scope.layout.qHyperCube.qMeasureInfo.length ){
								for( var i45 = 0 ; prop_nRowBreak1 > 1 && i45 < prop_nRowBreak1 - ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 ) ; i45++ ){
									if( prop_nMeasureCols >= 2 && prop_nHeaderWidth2 >0 ){// リピートする場合
										sHTML += "<td style='border-bottom: 1px solid black; border-left:3px double black;' ><p> </p></td>";
									}

									if(prop_nMeasureCols >= 2){
										if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
											sVLine4 = " "; // 縦罫線
										}
										else{
											sVLine4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 縦罫線
										}
									}
									else{
										if( $scope.layout.settings.sLineV1 == "none" ){// 縦罫線
											sVLine4 = " border-left: 3px double black;"; // 縦罫線
										}
										else{
											sVLine4 = " border-left: 1px " + $scope.layout.settings.sLineV1 + " black; "; // 縦罫線
										}
									}
									
									if( /*i45 == (prop_nRowBreak1 - ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 )-1) || */iy1 != $scope.layout.qHyperCube.qSize.qcy -1 ){
										if(prop_nMeasureCols >= 2){
											sHTML += "<td style='border-bottom: 1px solid black; border-right: 0px solid black; " + sVLine4 +" '><p> </p></td>";
										}
										else{
											sHTML += "<td style='border-bottom: 1px solid black; border-right: 0px solid black; border-left: 3px double black; '><p> </p></td>";
										}
									}
									else if( i45 == (prop_nRowBreak1 - ($scope.layout.qHyperCube.qMeasureInfo.length % prop_nRowBreak1 )-1) || iy1 == $scope.layout.qHyperCube.qSize.qcy -1 ){
										if(prop_nMeasureCols >= 2){
											sHTML += "<td style='border-bottom: 1px solid black; border-right: 1px solid black; " + sVLine4 +" '><p> </p></td>";
										}
										else{
											sHTML += "<td style='border-bottom: 1px solid black; border-right: 1px solid black; border-left: 3px double black; '><p> </p></td>";
										}
									}
									else{
										sHTML += "<td style='border-bottom: 1px solid black; " +sVLine4+ "'><p> </p></td>";
									}
								}
							}


							iy1 = iy1 + 1;
						}	// <<< while( iy1 < $scope.layout.qHyperCube.qSize.qcy &&
						
						sHTML += "<td ></td>";// dummy
						sHTML += "</tr>";



//$scope.sDEBUG += " i1+prop_nRowBreak1=" + (i1 + prop_nRowBreak1) + " /";

						i1 = i1 + prop_nRowBreak1; // メジャーがインクリメントされる







						
						iCurrentRow1 = iCurrentRow1 + 1; // 現在の行をインクリメントする
						if( iCurrentRow1 >= $scope.aryLv1[i2].RangesumRS && i2 < $scope.aryLv1.length ){
							i2++;
						}
						if( iCurrentRow1 >= $scope.aryLv2[i2b].RangesumRS && i2b < $scope.aryLv2.length ){
							i2b++;
						}
						
						
//$scope.sDEBUG += " i1=" + i1 + " /";
						
					}// <<< while 本体 ( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){// メジャー分ループ

					
					
					sHTML += "</table>";










					return sHTML ;
				
				}// <<<$scope.makeHTML = function()
				

				// --------------------------------------------------------------------------------------------
				$scope.mytable = function(){
				

					// デバッグ用コード
					$scope.sDEBUG = "丸野/";
//					$scope.sDEBUG += $scope.layout.visualization + "/";
//					// HELP https://help.qlik.com/en-US/sense-developer/June2020/Subsystems/EngineAPI/Content/Sense_EngineAPI/GenericObject/LayoutLevel/HyperCube.htm
//					var i2 = 0;
//					$scope.sDEBUG += "■ディメンション情報:"; 
//					while( i2 < $scope.layout.qHyperCube.qDimensionInfo.length ){
//						$scope.sDEBUG += $scope.layout.qHyperCube.qDimensionInfo[ i2 ].qFallbackTitle + "/";
//							i2 = i2 + 1;
//					}
//					var i1 = 0;
//					$scope.sDEBUG += "■メジャー情報:"; 
//					while( i1 < $scope.layout.qHyperCube.qMeasureInfo.length ){
//						$scope.sDEBUG += $scope.layout.qHyperCube.qMeasureInfo[ i1 ].qFallbackTitle + "/";
//						$scope.sDEBUG += $scope.layout.qHyperCube.qGrandTotalRow[ i1 ].qText + "//";
//						i1 = i1 + 1;
//					}
//					
//					var ix1,iy1;
//					$scope.sDEBUG += "■マトリックス情報:"; 
//					iy1 = 0;
//					while( iy1 < $scope.layout.qHyperCube.qSize.qcy ){
//						ix1=0; // ix1 が 0 の位置がヘッダ行だと思えばよい。
//						while( ix1 < $scope.layout.qHyperCube.qSize.qcx ){
//							$scope.sDEBUG += $scope.layout.qHyperCube.qDataPages[ 0 ].qMatrix[iy1][ix1].qText + "/";
//							ix1 = ix1 + 1;
//						}
//						iy1 = iy1 + 1;
//					}
					$scope.sDEBUG += "■"; 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					var sHTML="";

					// プロパティを配列にする					
					setPropAry();

					// HTMLを生成する
					sHTML = makeHTML();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					return sHTML;

				}// <<<$scope.mytable = function
				
				// --------------------------------------------------------------------------------------------
				<!-- $scopeは、HTMLのテンプレートとcontrollerの橋渡しをする。 -->
//				$scope.maruno = "丸野" + "/"; // 宣言もなく、好きなように変数をつけていい。ここではmarunoという変数を付けた。HTMLのテンプレートから{{で囲めば}}直接アクセスできる
			}]	// <<<controller: ['
		
        };	// <<<return
    } // <<<function ( qlik , template , props )
);	// <<<define


