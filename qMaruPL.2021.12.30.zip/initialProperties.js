// # Author
// Katsuaki Maruno
// 
// # Copyright
// Copyright ©2021 OTSUKA CORPORATION
// 
// # License
// The source code is licensed MIT. The website content is licensed CC BY 4.0,see LICENSE.

// JavaScript

define([], function(){
	return {
		version: 1.0,
		qHyperCubeDef: {
			qDimensions: [],
			qMeasures: [],
			qInitialDataFetch: [
				{
					qWidth: 100,
					qHeight: 30
				}
			]
		}

	}
})